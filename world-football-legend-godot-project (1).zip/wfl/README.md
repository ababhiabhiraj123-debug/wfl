# World Football Legend - Godot 4 vertical slice

Open this folder in **Godot 4.3+** (project.godot). Press F5 to run on desktop
(arrow keys = move, Shift = sprint, Z pass, X shoot, C through, V tackle/slide, B skill, Esc pause).

## Build the Android APK
1. Godot: Editor > Manage Export Templates > download for your version.
2. Install JDK 17 + Android SDK, then Editor Settings > Export > Android: set the SDK and JDK paths.
3. Project > Export > Add... > Android. Set a package name (e.g. com.yourname.wfl),
   keep Orientation = Landscape, tick "Export with Debug" for a test build.
4. Click "Export Project" and save as `wfl.apk`; copy it to your phone and install.

## What this slice contains
Main menu, player creator, career dashboard, 11v11 match engine with touch controls,
league table, training, transfers/contracts, season rollover, 3 save slots with autosave.

## Data
data/world.json holds the placeholder world (fictional clubs). Edit ratings in
Player Database (saved to user://world_import.json), or drop a licensed dataset of the
same format at that path.
