extends Control
## Main menu: Become a Legend, Continue, New Career, Player Database, Transfers, Settings.


func _ready() -> void:
	UI.background(self)
	var m := UI.margin(self, 40)
	var hb := HBoxContainer.new()
	hb.add_theme_constant_override("separation", 60)
	m.add_child(hb)
	var left := VBoxContainer.new()
	left.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	left.alignment = BoxContainer.ALIGNMENT_CENTER
	hb.add_child(left)
	left.add_child(UI.label("WORLD", 34, UI.ACCENT))
	left.add_child(UI.label("FOOTBALL", 72))
	left.add_child(UI.label("LEGEND", 72, UI.ACCENT))
	left.add_child(UI.label("Rise from unknown prospect to world-class legend.", 22, UI.MUTED))
	left.add_child(UI.label("Database updated: %s (placeholder data)" % Game.world.get("last_updated", "?"), 17, UI.MUTED))
	var right := VBoxContainer.new()
	right.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	right.alignment = BoxContainer.ALIGNMENT_CENTER
	right.add_theme_constant_override("separation", 10)
	hb.add_child(right)
	var items := [
		["Become a Legend", _legend, true],
		["Continue Career", _continue],
		["New Career", _new],
		["Player Database", _db],
		["Transfers", _transfers],
		["Settings", _settings],
		["Quit", _quit],
	]
	for it in items:
		right.add_child(UI.button(it[0], it[1], it.size() > 2, Vector2(0, 64)))


func _last_slot_ok() -> bool:
	var s: int = int(Game.settings["last_slot"])
	return s > 0 and FileAccess.file_exists(Game.save_path(s))


func _legend() -> void:
	if _last_slot_ok():
		_open_slot(int(Game.settings["last_slot"]), "res://scenes/dashboard.tscn")
	else:
		get_tree().change_scene_to_file("res://scenes/creator.tscn")


func _continue() -> void:
	var opts: Array = []
	for i in range(1, Game.SAVE_SLOTS + 1):
		var s := Game.slot_summary(i)
		if s != "":
			opts.append([s, _open_slot.bind(i, "res://scenes/dashboard.tscn")])
	if opts.is_empty():
		UI.modal(self, "Continue Career", "No saved careers yet. Start a New Career first.", [["OK", Callable()]])
		return
	opts.append(["Cancel", Callable()])
	UI.modal(self, "Continue Career", "Choose a save slot.", opts)


func _open_slot(i: int, scene: String) -> void:
	if Game.load_career(i):
		get_tree().change_scene_to_file(scene)
	else:
		UI.modal(self, "Load failed", "That save could not be read.", [["OK", Callable()]])


func _new() -> void:
	get_tree().change_scene_to_file("res://scenes/creator.tscn")


func _db() -> void:
	get_tree().change_scene_to_file("res://scenes/player_db.tscn")


func _transfers() -> void:
	if _last_slot_ok():
		_open_slot(int(Game.settings["last_slot"]), "res://scenes/transfers.tscn")
	else:
		UI.modal(self, "Transfers", "Start or load a career first. Transfers belong to your career.", [["OK", Callable()]])


func _settings() -> void:
	get_tree().change_scene_to_file("res://scenes/settings.tscn")


func _quit() -> void:
	get_tree().quit()
