extends Control
## Create your footballer: identity, body, appearance, position, starting club, save slot.

var first_name: LineEdit
var last_name: LineEdit
var nation: OptionButton
var by_spin: SpinBox
var bm_spin: SpinBox
var bd_spin: SpinBox
var height_spin: SpinBox
var weight_spin: SpinBox
var shirt_spin: SpinBox
var pos_opt: OptionButton
var foot_opt: OptionButton
var skin_opt: OptionButton
var hair_opt: OptionButton
var style_opt: OptionButton
var club_opt: OptionButton
var slot_opt: OptionButton
var avatar: Avatar
var club_ids: Array = []
var ref_year := 2026
var ref_month := 11
var ref_day := 11


func _ready() -> void:
	UI.background(self)
	var parts: PackedStringArray = str(Game.world.get("last_updated", "2026-11-11")).split("-")
	if parts.size() == 3:
		ref_year = int(parts[0])
		ref_month = int(parts[1])
		ref_day = int(parts[2])
	var m := UI.margin(self, 20)
	var root := VBoxContainer.new()
	root.add_theme_constant_override("separation", 8)
	m.add_child(root)
	root.add_child(UI.label("Create your footballer", 34, UI.ACCENT))
	var sc := ScrollContainer.new()
	sc.size_flags_vertical = Control.SIZE_EXPAND_FILL
	sc.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	root.add_child(sc)
	var cols := HBoxContainer.new()
	cols.add_theme_constant_override("separation", 30)
	cols.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	sc.add_child(cols)
	var left := VBoxContainer.new()
	left.add_theme_constant_override("separation", 8)
	left.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	cols.add_child(left)
	var right := VBoxContainer.new()
	right.add_theme_constant_override("separation", 8)
	right.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	cols.add_child(right)

	first_name = _line("First name")
	last_name = _line("Last name")
	_row(left, "First name", first_name)
	_row(left, "Last name", last_name)
	nation = _opt(Game.NATIONS)
	_row(left, "Nationality", nation)
	by_spin = _spin(ref_year - 21, ref_year - 16, ref_year - 18)
	bm_spin = _spin(1, 12, 6)
	bd_spin = _spin(1, 28, 15)
	var dob := HBoxContainer.new()
	dob.add_child(by_spin)
	dob.add_child(bm_spin)
	dob.add_child(bd_spin)
	_row(left, "Date of birth (Y / M / D)", dob)
	height_spin = _spin(160, 205, 180)
	weight_spin = _spin(55, 100, 74)
	shirt_spin = _spin(1, 99, 17)
	_row(left, "Height (cm)", height_spin)
	_row(left, "Weight (kg)", weight_spin)
	_row(left, "Shirt number", shirt_spin)

	pos_opt = _opt(Game.POSITIONS)
	pos_opt.selected = Game.POSITIONS.find("CF")
	_row(right, "Position", pos_opt)
	foot_opt = _opt(["Right", "Left", "Both"])
	_row(right, "Preferred foot", foot_opt)
	style_opt = _opt(Avatar.STYLES)
	hair_opt = _opt(["Black", "Brown", "Blonde", "Red", "Grey"])
	skin_opt = _opt(["Skin 1", "Skin 2", "Skin 3", "Skin 4", "Skin 5"])
	skin_opt.selected = 1
	for o in [style_opt, hair_opt, skin_opt]:
		o.item_selected.connect(_refresh_avatar)
	_row(right, "Hairstyle", style_opt)
	_row(right, "Hair colour", hair_opt)
	_row(right, "Skin tone", skin_opt)
	var club_names: Array = ["Free agent (unattached)"]
	club_ids = [""]
	for c in Game.world["clubs"]:
		club_ids.append(str(c["id"]))
		club_names.append("%s (rating %d)" % [c["name"], int(c["rating"])])
	club_opt = _opt(club_names)
	club_opt.selected = club_ids.size() - 1
	_row(right, "Starting club", club_opt)
	var slot_names: Array = []
	for i in range(1, Game.SAVE_SLOTS + 1):
		var s := Game.slot_summary(i)
		slot_names.append("Slot %d: %s" % [i, "empty" if s == "" else "overwrite"])
	slot_opt = _opt(slot_names)
	_row(right, "Save slot", slot_opt)
	avatar = Avatar.new()
	avatar.custom_minimum_size = Vector2(190, 190)
	right.add_child(avatar)
	_refresh_avatar(0)

	var bottom := HBoxContainer.new()
	bottom.add_theme_constant_override("separation", 10)
	root.add_child(bottom)
	var back := UI.button("Back", _back, false, Vector2(0, 64))
	back.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	bottom.add_child(back)
	var go := UI.button("Start career", _start, true, Vector2(0, 64))
	go.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	bottom.add_child(go)


func _line(ph: String) -> LineEdit:
	var l := LineEdit.new()
	l.placeholder_text = ph
	l.custom_minimum_size = Vector2(320, 56)
	l.add_theme_font_size_override("font_size", 22)
	return l


func _opt(items: Array) -> OptionButton:
	var o := OptionButton.new()
	o.custom_minimum_size = Vector2(320, 56)
	o.add_theme_font_size_override("font_size", 22)
	for it in items:
		o.add_item(str(it))
	return o


func _spin(lo: int, hi: int, v: int) -> SpinBox:
	var s := SpinBox.new()
	s.min_value = lo
	s.max_value = hi
	s.value = v
	s.custom_minimum_size = Vector2(100, 56)
	return s


func _row(parent: Control, text: String, ctl: Control) -> void:
	var v := VBoxContainer.new()
	v.add_child(UI.label(text, 18, UI.MUTED))
	v.add_child(ctl)
	parent.add_child(v)


func _refresh_avatar(_i: int) -> void:
	avatar.setup(Avatar.SKINS[skin_opt.selected], Avatar.HAIRS[hair_opt.selected], style_opt.selected)


func _age() -> int:
	var age: int = ref_year - int(by_spin.value)
	if int(bm_spin.value) > ref_month or (int(bm_spin.value) == ref_month and int(bd_spin.value) > ref_day):
		age -= 1
	return age


func _start() -> void:
	var fn := first_name.text.strip_edges()
	var ln := last_name.text.strip_edges()
	if fn == "" or ln == "":
		UI.modal(self, "Name needed", "Please enter a first and last name.", [["OK", Callable()]])
		return
	Game.slot = slot_opt.selected + 1
	var opts := {
		"name": fn + " " + ln,
		"pos": Game.POSITIONS[pos_opt.selected],
		"foot": foot_opt.get_item_text(foot_opt.selected),
		"nat": Game.NATIONS[nation.selected],
		"age": _age(),
		"height": int(height_spin.value),
		"weight": int(weight_spin.value),
		"shirt": int(shirt_spin.value),
		"club_id": club_ids[club_opt.selected],
		"look": {"skin": skin_opt.selected, "hair": hair_opt.selected, "style": style_opt.selected},
	}
	Game.new_career(opts)
	get_tree().change_scene_to_file("res://scenes/dashboard.tscn")


func _back() -> void:
	get_tree().change_scene_to_file("res://scenes/main_menu.tscn")
