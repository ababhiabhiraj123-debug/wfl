extends Node
## Global state: world database, career manager, league manager, training,
## transfer manager, statistics and save system (all in one autoload for the slice).

const SAVE_SLOTS := 3
const ROUNDS := 14
const POSITIONS := ["GK", "CB", "LB", "RB", "DMF", "CMF", "AMF", "LMF", "RMF", "LWF", "RWF", "SS", "CF"]
const ATTRS := ["speed", "stamina", "strength", "ball_control", "dribbling", "finishing", "passing", "tackling", "positioning", "heading", "goalkeeping"]
const WEIGHTS := {
	"GK": {"goalkeeping": 1.0},
	"DEF": {"tackling": 0.3, "strength": 0.15, "positioning": 0.2, "speed": 0.1, "heading": 0.15, "passing": 0.1},
	"MID": {"passing": 0.25, "ball_control": 0.2, "stamina": 0.15, "tackling": 0.1, "dribbling": 0.15, "positioning": 0.15},
	"ATT": {"finishing": 0.3, "dribbling": 0.2, "speed": 0.2, "ball_control": 0.15, "positioning": 0.1, "heading": 0.05},
}
const NATIONS := ["India", "England", "Spain", "Germany", "France", "Brazil", "Argentina", "Portugal", "Netherlands", "Italy", "Nigeria", "Ghana", "Morocco", "Japan", "South Korea", "USA", "Mexico", "Australia", "Saudi Arabia"]

var world: Dictionary = {}
var career: Dictionary = {}
var slot: int = 1
var settings: Dictionary = {"volume": 0.8, "quality": 1, "last_slot": 0}
var pending_match: Dictionary = {}
var last_result: Dictionary = {}
var rng := RandomNumberGenerator.new()


func _ready() -> void:
	rng.randomize()
	load_world()
	load_settings()
	apply_settings()


# ---------------------------------------------------------------- settings
func load_settings() -> void:
	var cf := ConfigFile.new()
	if cf.load("user://settings.cfg") == OK:
		settings["volume"] = cf.get_value("audio", "volume", 0.8)
		settings["quality"] = cf.get_value("video", "quality", 1)
		settings["last_slot"] = cf.get_value("game", "last_slot", 0)


func save_settings() -> void:
	var cf := ConfigFile.new()
	cf.set_value("audio", "volume", settings["volume"])
	cf.set_value("video", "quality", settings["quality"])
	cf.set_value("game", "last_slot", settings["last_slot"])
	cf.save("user://settings.cfg")


func apply_settings() -> void:
	AudioServer.set_bus_volume_db(0, linear_to_db(maxf(0.001, float(settings["volume"]))))
	Engine.max_fps = 60 if int(settings["quality"]) >= 1 else 30


# ---------------------------------------------------------------- world data
func load_world() -> void:
	var path := "res://data/world.json"
	if FileAccess.file_exists("user://world_import.json"):
		path = "user://world_import.json"
	var parsed: Variant = JSON.parse_string(FileAccess.get_file_as_string(path))
	if parsed is Dictionary and parsed.has("clubs"):
		world = parsed
	else:
		world = JSON.parse_string(FileAccess.get_file_as_string("res://data/world.json"))


func save_world_edits() -> void:
	var f := FileAccess.open("user://world_import.json", FileAccess.WRITE)
	if f:
		f.store_string(JSON.stringify(world, "  "))
		f.close()


func club(id: String) -> Dictionary:
	for c in world["clubs"]:
		if c["id"] == id:
			return c
	return {}


func club_name(id: String) -> String:
	if id == "":
		return "Free agent"
	return str(club(id).get("name", "?"))


func club_ids() -> Array:
	var out: Array = []
	for c in world["clubs"]:
		out.append(c["id"])
	return out


func make_name(r: RandomNumberGenerator) -> String:
	var fn: Array = world["first_names"]
	var ln: Array = world["last_names"]
	return "%s %s" % [fn[r.randi_range(0, fn.size() - 1)], ln[r.randi_range(0, ln.size() - 1)]]


func squad_for(club_id: String) -> Array:
	var r := RandomNumberGenerator.new()
	r.seed = hash(club_id)
	var layout := ["GK", "GK", "CB", "CB", "CB", "LB", "RB", "DMF", "CMF", "CMF", "AMF", "LMF", "RMF", "LWF", "RWF", "SS", "CF", "CF"]
	var base: int = int(club(club_id).get("rating", 55))
	var out: Array = []
	for i in layout.size():
		out.append({
			"name": make_name(r),
			"pos": layout[i],
			"age": r.randi_range(18, 34),
			"ovr": clampi(base + r.randi_range(-9, 6), 40, 90),
		})
	return out


# ---------------------------------------------------------------- ratings
func pos_group(pos: String) -> String:
	if pos == "GK":
		return "GK"
	if pos == "CB" or pos == "LB" or pos == "RB":
		return "DEF"
	if pos == "LWF" or pos == "RWF" or pos == "SS" or pos == "CF":
		return "ATT"
	return "MID"


func calc_ovr(a: Dictionary, pos: String) -> int:
	var w: Dictionary = WEIGHTS[pos_group(pos)]
	var total := 0.0
	for k in w:
		total += float(a.get(k, 40)) * float(w[k])
	return int(round(total))


func current_ovr() -> int:
	return calc_ovr(career["attrs"], str(career["pos"]))


func make_attrs(pos: String, ovr: int) -> Dictionary:
	var a: Dictionary = {}
	for k in ATTRS:
		a[k] = clampi(ovr + rng.randi_range(-6, 6), 25, 95)
	var g := pos_group(pos)
	if g == "GK":
		for k in ATTRS:
			if k != "goalkeeping":
				a[k] = clampi(ovr - 25 + rng.randi_range(-5, 5), 20, 80)
	else:
		a["goalkeeping"] = rng.randi_range(8, 22)
		if g == "ATT":
			a["tackling"] = clampi(ovr - 18, 20, 90)
		elif g == "DEF":
			a["finishing"] = clampi(ovr - 18, 20, 90)
	var diff: int = ovr - calc_ovr(a, pos)
	for k in WEIGHTS[g]:
		a[k] = clampi(int(a[k]) + diff, 20, 99)
	return a


# ---------------------------------------------------------------- career
func _blank_stats() -> Dictionary:
	return {"apps": 0, "goals": 0, "assists": 0, "yellow": 0, "red": 0, "rating_sum": 0.0, "minutes": 0}


func wage_for(ovr: int, rating: int) -> int:
	return int((500.0 + ovr * ovr * 0.4 * (1.0 + (rating - 60) / 100.0)) / 10.0) * 10


func season_label() -> String:
	var y: int = int(career["year"])
	return "%d/%02d" % [y, (y + 1) % 100]


func add_news(text: String) -> void:
	var n: Array = career["news"]
	n.push_front(text)
	while n.size() > 12:
		n.pop_back()


func new_career(o: Dictionary) -> void:
	var start_ovr := rng.randi_range(48, 56)
	var pot := mini(96, start_ovr + rng.randi_range(22, 34))
	var year := int(str(world.get("last_updated", "2026-07-01")).substr(0, 4))
	career = {
		"name": o["name"], "pos": o["pos"], "foot": o["foot"], "nat": o["nat"], "age": o["age"],
		"height": o["height"], "weight": o["weight"], "shirt": o["shirt"], "look": o["look"],
		"club_id": o["club_id"], "wage": 0, "contract_years": 0,
		"attrs": make_attrs(str(o["pos"]), start_ovr), "pot": pot,
		"season": 1, "year": year, "round": 0,
		"fatigue": 0.0, "morale": 70.0, "trust": 40.0, "fans": 10.0, "injury_weeks": 0, "form": [],
		"training_done": false, "fixtures": [], "table": {},
		"cur": _blank_stats(), "totals": _blank_stats(), "seasons": [], "clubs_history": [],
		"trophies": [], "awards": [], "news": [], "offers": [], "pending_summary": "",
	}
	if str(o["club_id"]) != "":
		career["wage"] = wage_for(start_ovr, int(club(str(o["club_id"]))["rating"]))
		career["contract_years"] = 3
		career["clubs_history"].append(club_name(str(o["club_id"])))
		add_news("You signed your first contract with %s." % club_name(str(o["club_id"])))
	else:
		career["offers"] = generate_offers()
		add_news("You are a free agent. Check the Transfers screen for offers.")
	start_season()
	save_career()


func start_season() -> void:
	var ids: Array = club_ids()
	career["fixtures"] = generate_fixtures(ids)
	var t: Dictionary = {}
	for id in ids:
		t[id] = {"p": 0, "w": 0, "d": 0, "l": 0, "gf": 0, "ga": 0, "pts": 0}
	career["table"] = t
	career["round"] = 0
	career["training_done"] = false


func generate_fixtures(ids: Array) -> Array:
	var teams: Array = ids.duplicate()
	var n := teams.size()
	var rounds: Array = []
	for r in range(n - 1):
		var rd: Array = []
		for i in range(n / 2):
			var a: String = teams[i]
			var b: String = teams[n - 1 - i]
			if r % 2 == 0:
				rd.append([a, b])
			else:
				rd.append([b, a])
		rounds.append(rd)
		var last: String = teams.pop_back()
		teams.insert(1, last)
	var second: Array = []
	for rd in rounds:
		var rr: Array = []
		for m in rd:
			rr.append([m[1], m[0]])
		second.append(rr)
	rounds.append_array(second)
	return rounds


func next_match() -> Dictionary:
	if str(career["club_id"]) == "" or int(career["round"]) >= ROUNDS:
		return {}
	for m in career["fixtures"][int(career["round"])]:
		if m[0] == career["club_id"] or m[1] == career["club_id"]:
			return {"home": m[0], "away": m[1]}
	return {}


func apply_result(h: String, a: String, hg: int, ag: int) -> void:
	var t: Dictionary = career["table"]
	var th: Dictionary = t[h]
	var ta: Dictionary = t[a]
	th["p"] += 1
	ta["p"] += 1
	th["gf"] += hg
	th["ga"] += ag
	ta["gf"] += ag
	ta["ga"] += hg
	if hg > ag:
		th["w"] += 1
		th["pts"] += 3
		ta["l"] += 1
	elif hg < ag:
		ta["w"] += 1
		ta["pts"] += 3
		th["l"] += 1
	else:
		th["d"] += 1
		ta["d"] += 1
		th["pts"] += 1
		ta["pts"] += 1


func _cmp_table(a: Dictionary, b: Dictionary) -> bool:
	var ra: Dictionary = a["r"]
	var rb: Dictionary = b["r"]
	if ra["pts"] != rb["pts"]:
		return ra["pts"] > rb["pts"]
	var gda: int = int(ra["gf"]) - int(ra["ga"])
	var gdb: int = int(rb["gf"]) - int(rb["ga"])
	if gda != gdb:
		return gda > gdb
	return ra["gf"] > rb["gf"]


func table_sorted() -> Array:
	var arr: Array = []
	for id in career["table"]:
		arr.append({"id": id, "r": career["table"][id]})
	arr.sort_custom(_cmp_table)
	return arr


func position_of(club_id: String) -> int:
	var i := 1
	for e in table_sorted():
		if e["id"] == club_id:
			return i
		i += 1
	return 0


func ordinal(n: int) -> String:
	var suffix := "th"
	if n % 100 < 11 or n % 100 > 13:
		if n % 10 == 1:
			suffix = "st"
		elif n % 10 == 2:
			suffix = "nd"
		elif n % 10 == 3:
			suffix = "rd"
	return "%d%s" % [n, suffix]


func _poisson(l: float) -> int:
	var lim := exp(-l)
	var k := 0
	var p := rng.randf()
	while p > lim:
		k += 1
		p *= rng.randf()
	return k


func sim_match(h: String, a: String) -> Array:
	var rh: float = float(club(h)["rating"])
	var ra: float = float(club(a)["rating"])
	var lh := clampf(1.35 * exp((rh - ra + 4.0) / 30.0), 0.3, 4.0)
	var la := clampf(1.10 * exp((ra - rh - 4.0) / 30.0), 0.3, 4.0)
	return [_poisson(lh), _poisson(la)]


func squad_status() -> String:
	if str(career["club_id"]) == "":
		return "Free agent"
	var cr: float = float(club(str(career["club_id"]))["rating"])
	var diff: float = float(current_ovr()) + (float(career["trust"]) - 50.0) * 0.15 - cr
	if diff >= -3.0:
		return "Starter"
	if diff >= -10.0:
		return "Rotation"
	return "Bench"


func match_role() -> Dictionary:
	if int(career["injury_weeks"]) > 0:
		return {"enter": 999.0, "status": "Injured"}
	var st := squad_status()
	if st == "Starter":
		return {"enter": 0.0, "status": "Starter"}
	if st == "Rotation":
		if rng.randf() < 0.5:
			return {"enter": 0.0, "status": "Starter"}
		return {"enter": 60.0 + float(rng.randi_range(0, 10)), "status": "Substitute"}
	if rng.randf() < 0.7:
		return {"enter": 72.0 + float(rng.randi_range(0, 8)), "status": "Substitute"}
	return {"enter": 999.0, "status": "Unused substitute"}


func sim_user_match(status: String) -> void:
	var nm := next_match()
	var g := sim_match(nm["home"], nm["away"])
	var res := {
		"home": nm["home"], "away": nm["away"], "hg": g[0], "ag": g[1], "status": status,
		"user": {"minutes": 0, "rating": 0.0, "goals": 0, "assists": 0, "passes": 0, "passes_ok": 0,
			"shots": 0, "tackles": 0, "distance": 0.0, "yellow": 0, "red": 0},
	}
	finish_match(res)


func finish_match(res: Dictionary) -> void:
	var c := career
	apply_result(res["home"], res["away"], int(res["hg"]), int(res["ag"]))
	var u: Dictionary = res["user"]
	var mins := int(u["minutes"])
	var mine: bool = res["home"] == c["club_id"]
	var my_goals: int = int(res["hg"]) if mine else int(res["ag"])
	var opp_goals: int = int(res["ag"]) if mine else int(res["hg"])
	var feedback := ""
	var media := ""
	if mins > 0:
		var rating := float(u["rating"])
		for st in [c["cur"], c["totals"]]:
			st["apps"] += 1
			st["goals"] += int(u["goals"])
			st["assists"] += int(u["assists"])
			st["yellow"] += int(u["yellow"])
			st["red"] += int(u["red"])
			st["rating_sum"] += rating
			st["minutes"] += mins
		var form: Array = c["form"]
		form.append(rating)
		if form.size() > 5:
			form.pop_front()
		var result_bonus := 3.0 if my_goals > opp_goals else (-2.0 if my_goals < opp_goals else 0.0)
		c["trust"] = clampf(float(c["trust"]) + (rating - 6.6) * 4.0, 0.0, 100.0)
		c["morale"] = clampf(float(c["morale"]) + result_bonus + (rating - 6.6) * 2.0, 0.0, 100.0)
		c["fans"] = clampf(float(c["fans"]) + int(u["goals"]) * 2.0 + int(u["assists"]) + (rating - 6.5) * 0.8, 0.0, 100.0)
		c["fatigue"] = clampf(float(c["fatigue"]) + 8.0 + 14.0 * mins / 90.0, 0.0, 100.0)
		if rating >= 8.0:
			feedback = "Outstanding performance today. You've earned my trust."
			media = "Fans and pundits are raving about your display."
		elif rating >= 7.0:
			feedback = "Good game. Keep working in training."
			media = "A solid, promising showing from the youngster."
		elif rating >= 6.0:
			feedback = "Fine, but I want more from you next time."
			media = "A quiet afternoon for the youngster."
		else:
			feedback = "That wasn't good enough. Work harder."
			media = "Criticism grows after a poor display."
		if rng.randf() < 0.03 + float(c["fatigue"]) / 1500.0:
			c["injury_weeks"] = rng.randi_range(1, 4) + 1
			add_news("You picked up an injury (%d weeks out)." % (int(c["injury_weeks"]) - 1))
		add_news("%s %d-%d %s. Your rating: %.1f" % [club_name(res["home"]), int(res["hg"]), int(res["ag"]), club_name(res["away"]), rating])
	else:
		feedback = "You were not involved today (%s)." % str(res.get("status", ""))
		media = ""
		c["morale"] = clampf(float(c["morale"]) - 1.0, 0.0, 100.0)
		add_news("%s %d-%d %s." % [club_name(res["home"]), int(res["hg"]), int(res["ag"]), club_name(res["away"])])
	last_result = {"res": res, "feedback": feedback, "media": media}
	advance_round(str(res["home"]), str(res["away"]))
	save_career()


func advance_round(skip_h: String, skip_a: String) -> void:
	var r := int(career["round"])
	if r < ROUNDS:
		for m in career["fixtures"][r]:
			if m[0] == skip_h and m[1] == skip_a:
				continue
			var g := sim_match(m[0], m[1])
			apply_result(m[0], m[1], g[0], g[1])
	career["round"] = r + 1
	career["training_done"] = false
	career["fatigue"] = maxf(0.0, float(career["fatigue"]) - 12.0)
	if int(career["injury_weeks"]) > 0:
		career["injury_weeks"] = int(career["injury_weeks"]) - 1
	if not transfer_window_open():
		career["offers"] = []
	if int(career["round"]) >= ROUNDS:
		end_season()


func end_season() -> void:
	var c := career
	var cid: String = c["club_id"]
	var pos := position_of(cid) if cid != "" else 0
	var cur: Dictionary = c["cur"]
	var apps := int(cur["apps"])
	var avg := 6.0
	if apps > 0:
		avg = float(cur["rating_sum"]) / float(apps)
	var label := season_label()
	var before := current_ovr()
	develop_season(avg)
	var after := current_ovr()
	c["seasons"].append({
		"season": c["season"], "label": label, "club": club_name(cid), "pos": pos,
		"apps": apps, "goals": cur["goals"], "assists": cur["assists"],
		"rating": snappedf(avg, 0.01), "ovr": after,
	})
	var summary := "Season %s complete.\n" % label
	if cid != "":
		summary += "%s finished %s.\n" % [club_name(cid), ordinal(pos)]
	summary += "Apps %d · Goals %d · Assists %d · Avg rating %.2f\n" % [apps, int(cur["goals"]), int(cur["assists"]), avg]
	summary += "Overall %d → %d" % [before, after]
	if pos == 1:
		c["trophies"].append("%s %s" % [world["league"], label])
		summary += "\nCHAMPIONS! Trophy added to your cabinet."
	if apps >= 8 and avg >= 7.4:
		c["awards"].append("Club Player of the Season %s" % label)
		summary += "\nAward: Club Player of the Season."
	if apps >= 6 and avg >= 7.0 and int(c["age"]) <= 21:
		c["awards"].append("Young Player of the Season %s" % label)
		summary += "\nAward: Young Player of the Season."
	c["age"] = int(c["age"]) + 1
	c["year"] = int(c["year"]) + 1
	c["season"] = int(c["season"]) + 1
	c["cur"] = _blank_stats()
	c["fatigue"] = 0.0
	c["injury_weeks"] = 0
	if cid != "":
		c["contract_years"] = int(c["contract_years"]) - 1
		if int(c["contract_years"]) <= 0:
			c["club_id"] = ""
			c["wage"] = 0
			summary += "\nYour contract expired. You are a free agent."
			add_news("Your contract at %s expired." % club_name(cid))
	c["offers"] = generate_offers()
	if (c["offers"] as Array).size() > 0:
		summary += "\nYou have %d transfer offer(s) waiting." % (c["offers"] as Array).size()
	start_season()
	c["pending_summary"] = summary
	add_news("Season %s finished." % label)


func develop_season(avg: float) -> void:
	var age := int(career["age"])
	var ovr := current_ovr()
	var f := 1.0 if age <= 21 else (0.7 if age <= 25 else (0.3 if age <= 29 else -0.5))
	var pts := 0
	if f > 0.0:
		var gap := maxf(0.0, float(int(career["pot"]) - ovr))
		pts = int(round(gap * 0.28 * f + (avg - 6.4) * 2.0))
	else:
		pts = -int(round(1.0 + (age - 29) * 0.6))
	pts = clampi(pts, -6, 9)
	var keys: Array = (WEIGHTS[pos_group(str(career["pos"]))] as Dictionary).keys()
	var sgn := 1 if pts > 0 else -1
	for i in absi(pts) * 5:
		var k: String = keys[rng.randi_range(0, keys.size() - 1)]
		career["attrs"][k] = clampi(int(career["attrs"][k]) + sgn, 20, 99)


func train(kind: String) -> String:
	if career["training_done"]:
		return "You have already trained this week."
	if kind == "rest":
		career["fatigue"] = maxf(0.0, float(career["fatigue"]) - 35.0)
		career["morale"] = minf(100.0, float(career["morale"]) + 2.0)
		career["training_done"] = true
		save_career()
		return "You rested. Fatigue reduced."
	if int(career["injury_weeks"]) > 0:
		return "You are injured. Rest only."
	var sets := {
		"attack": ["finishing", "dribbling", "ball_control", "speed"],
		"defend": ["tackling", "positioning", "heading", "strength"],
		"passing": ["passing", "ball_control", "positioning", "dribbling"],
		"fitness": ["speed", "stamina", "strength"],
	}
	var keys: Array = sets[kind]
	if str(career["pos"]) == "GK":
		keys = ["goalkeeping", "positioning", "stamina"]
	var gap := maxf(0.0, float(int(career["pot"]) - current_ovr()))
	var p := clampf(0.3 + gap * 0.02 + (0.1 if float(career["fatigue"]) < 40.0 else -0.1), 0.1, 0.8)
	var gained: Array = []
	for i in 2:
		if rng.randf() < p:
			var k: String = keys[rng.randi_range(0, keys.size() - 1)]
			career["attrs"][k] = mini(99, int(career["attrs"][k]) + 1)
			gained.append("+1 " + k.replace("_", " "))
	career["fatigue"] = minf(100.0, float(career["fatigue"]) + 12.0)
	career["training_done"] = true
	save_career()
	if gained.is_empty():
		return "Hard session, but no visible progress this week."
	return "Training complete: " + ", ".join(gained)


# ---------------------------------------------------------------- transfers
func transfer_window_open() -> bool:
	return str(career["club_id"]) == "" or [0, 1, 7].has(int(career["round"]))


func generate_offers() -> Array:
	var out: Array = []
	var ovr := current_ovr()
	var lowest: Dictionary = {}
	for cl in world["clubs"]:
		if cl["id"] == career["club_id"]:
			continue
		if lowest.is_empty() or int(cl["rating"]) < int(lowest["rating"]):
			lowest = cl
		var rating: int = int(cl["rating"])
		if rating <= ovr + 14 + int(float(career["fans"]) * 0.1) and rng.randf() < 0.75:
			out.append(_make_offer(cl, ovr))
	if out.is_empty() and str(career["club_id"]) == "" and not lowest.is_empty():
		out.append(_make_offer(lowest, ovr))
	return out


func _make_offer(cl: Dictionary, ovr: int) -> Dictionary:
	return {"club_id": cl["id"], "wage": wage_for(ovr, int(cl["rating"])), "years": rng.randi_range(2, 4)}


func request_transfer() -> String:
	if not transfer_window_open():
		return "The transfer window is closed. It opens in rounds 1-2 and round 8, or when you are a free agent."
	career["offers"] = generate_offers()
	var n: int = (career["offers"] as Array).size()
	add_news("Your agent contacted clubs about a move.")
	save_career()
	if n == 0:
		return "Your agent found no interested clubs. Improve your rating and try again."
	return "Your agent has %d offer(s) for you." % n


func accept_offer(i: int) -> String:
	var o: Dictionary = career["offers"][i]
	career["club_id"] = o["club_id"]
	career["wage"] = o["wage"]
	career["contract_years"] = o["years"]
	career["trust"] = 45.0
	career["offers"] = []
	var nm := club_name(str(o["club_id"]))
	var hist: Array = career["clubs_history"]
	if hist.is_empty() or hist[hist.size() - 1] != nm:
		hist.append(nm)
	add_news("You signed for %s." % nm)
	save_career()
	return "Welcome to %s! %d-year deal on %d per week." % [nm, int(o["years"]), int(o["wage"])]


func reject_offer(i: int) -> void:
	(career["offers"] as Array).remove_at(i)
	save_career()


func negotiate_extension(ask_more: bool) -> String:
	if str(career["club_id"]) == "":
		return "You have no club."
	if int(career["contract_years"]) > 1:
		return "Your club will only talk once your contract has 1 year left."
	var rating: float = float(club(str(career["club_id"]))["rating"])
	var chance := 0.55 + (float(career["trust"]) - 40.0) * 0.006 + (float(current_ovr()) - rating) * 0.01
	if ask_more:
		chance -= 0.25
	if rng.randf() < chance:
		career["contract_years"] = 3
		career["wage"] = int(float(career["wage"]) * (1.3 if ask_more else 1.12))
		save_career()
		return "Agreed: 3 more years on %d per week." % int(career["wage"])
	career["trust"] = maxf(0.0, float(career["trust"]) - 5.0)
	save_career()
	return "The club rejected your demands."


# ---------------------------------------------------------------- saving
func save_path(i: int) -> String:
	return "user://career_%d.json" % i


func save_career() -> void:
	if career.is_empty():
		return
	var p := save_path(slot)
	var tmp := p + ".tmp"
	var f := FileAccess.open(tmp, FileAccess.WRITE)
	if f == null:
		return
	f.store_string(JSON.stringify(career))
	f.close()
	if FileAccess.file_exists(p):
		DirAccess.remove_absolute(p)
	DirAccess.rename_absolute(tmp, p)
	settings["last_slot"] = slot
	save_settings()


func load_career(i: int) -> bool:
	if not FileAccess.file_exists(save_path(i)):
		return false
	var parsed: Variant = JSON.parse_string(FileAccess.get_file_as_string(save_path(i)))
	if not (parsed is Dictionary):
		return false
	career = parsed
	for k in ["round", "season", "year", "age", "shirt", "contract_years", "wage", "injury_weeks", "pot", "height", "weight"]:
		career[k] = int(career[k])
	slot = i
	settings["last_slot"] = i
	save_settings()
	return true


func slot_summary(i: int) -> String:
	if not FileAccess.file_exists(save_path(i)):
		return ""
	var parsed: Variant = JSON.parse_string(FileAccess.get_file_as_string(save_path(i)))
	if not (parsed is Dictionary):
		return ""
	var d: Dictionary = parsed
	return "Slot %d: %s · %s · Season %d · OVR %d" % [i, d["name"], club_name(str(d["club_id"])), int(d["season"]), calc_ovr(d["attrs"], str(d["pos"]))]
