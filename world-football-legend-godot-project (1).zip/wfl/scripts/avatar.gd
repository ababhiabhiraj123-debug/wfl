class_name Avatar
extends Control
## Simple drawn head used in the player creator and dashboard.

const SKINS := [Color("F1C9A5"), Color("E0AC83"), Color("C68642"), Color("8D5524"), Color("5C3A1E")]
const HAIRS := [Color("1A1A1A"), Color("5B3A1E"), Color("D8B45A"), Color("A5421F"), Color("CFCFCF")]
const STYLES := ["Short", "Crop", "Afro", "Long", "Bald", "Mohawk"]

var skin: Color = SKINS[1]
var hair: Color = HAIRS[0]
var style: int = 0


func setup(s: Color, h: Color, st: int) -> void:
	skin = s
	hair = h
	style = st
	queue_redraw()


func _draw() -> void:
	var c := size / 2.0
	var r := minf(size.x, size.y) * 0.3
	draw_rect(Rect2(c.x - r * 1.3, c.y + r * 1.1, r * 2.6, r * 1.3), Color("35C46A"))
	if style == 2:
		draw_circle(c + Vector2(0, -r * 0.15), r * 1.3, hair)
	if style == 3:
		draw_rect(Rect2(c.x - r * 1.05, c.y - r * 0.3, r * 2.1, r * 1.6), hair)
	draw_circle(c, r, skin)
	if style == 0:
		draw_arc(c, r * 0.85, PI * 1.05, PI * 1.95, 20, hair, r * 0.5)
	elif style == 1:
		draw_arc(c, r * 0.95, PI * 1.15, PI * 1.85, 20, hair, r * 0.2)
	elif style == 3:
		draw_arc(c, r * 0.85, PI * 1.0, PI * 2.0, 20, hair, r * 0.5)
	elif style == 5:
		draw_rect(Rect2(c.x - r * 0.15, c.y - r * 1.3, r * 0.3, r * 0.8), hair)
	draw_circle(c + Vector2(-r * 0.35, -r * 0.05), r * 0.09, Color.BLACK)
	draw_circle(c + Vector2(r * 0.35, -r * 0.05), r * 0.09, Color.BLACK)
	draw_arc(c + Vector2(0, r * 0.2), r * 0.35, 0.3, PI - 0.3, 12, Color("5A2D2D"), 2.0)
