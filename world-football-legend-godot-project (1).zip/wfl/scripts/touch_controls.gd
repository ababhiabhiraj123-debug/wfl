class_name TouchControls
extends Control
## Floating joystick (left half) plus action buttons (right). Handles real multi-touch.

signal action(action_name: StringName)

const JOY_R := 95.0

var move := Vector2.ZERO
var sprint := false

var _joy_id := -1
var _joy_origin := Vector2.ZERO
var _joy_pos := Vector2.ZERO
var _touch_btn: Dictionary = {}   # finger index -> button key
var _btns: Dictionary = {}        # key -> {"c": Vector2, "r": float, "t": String}
var _pressed: Dictionary = {}


func _ready() -> void:
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	set_anchors_preset(Control.PRESET_FULL_RECT)
	get_viewport().size_changed.connect(_layout)
	_layout()


func _layout() -> void:
	var s := get_viewport_rect().size
	_btns = {
		"shoot": {"c": Vector2(s.x - 120, s.y - 130), "r": 62.0, "t": "SHOOT"},
		"pass": {"c": Vector2(s.x - 255, s.y - 90), "r": 50.0, "t": "PASS"},
		"through": {"c": Vector2(s.x - 255, s.y - 215), "r": 46.0, "t": "THRU"},
		"tackle": {"c": Vector2(s.x - 120, s.y - 270), "r": 46.0, "t": "TACKLE"},
		"dribble": {"c": Vector2(s.x - 385, s.y - 75), "r": 40.0, "t": "SKILL"},
		"sprint": {"c": Vector2(s.x - 385, s.y - 190), "r": 40.0, "t": "SPRINT"},
		"pause": {"c": Vector2(60, 60), "r": 34.0, "t": "II"},
		"cam": {"c": Vector2(s.x - 60, 60), "r": 34.0, "t": "CAM"},
	}
	queue_redraw()


func release_all() -> void:
	_joy_id = -1
	move = Vector2.ZERO
	sprint = false
	_touch_btn.clear()
	_pressed.clear()
	queue_redraw()


func _input(event: InputEvent) -> void:
	if event is InputEventScreenTouch:
		var e := event as InputEventScreenTouch
		if e.pressed:
			_down(e.index, e.position)
		else:
			_up(e.index)
	elif event is InputEventScreenDrag:
		var d := event as InputEventScreenDrag
		_drag(d.index, d.position)


func _hit(p: Vector2) -> String:
	for k in _btns:
		var b: Dictionary = _btns[k]
		var c: Vector2 = b["c"]
		if p.distance_to(c) <= float(b["r"]) + 12.0:
			return str(k)
	return ""


func _down(i: int, p: Vector2) -> void:
	var k := _hit(p)
	if k != "":
		_touch_btn[i] = k
		_pressed[k] = true
		if k == "sprint":
			sprint = true
		else:
			action.emit(StringName(k))
	elif _joy_id == -1 and p.x < get_viewport_rect().size.x * 0.5:
		_joy_id = i
		_joy_origin = p
		_joy_pos = p
		move = Vector2.ZERO
	queue_redraw()


func _up(i: int) -> void:
	if _touch_btn.has(i):
		var k: String = _touch_btn[i]
		_pressed[k] = false
		if k == "sprint":
			sprint = false
		_touch_btn.erase(i)
	if i == _joy_id:
		_joy_id = -1
		move = Vector2.ZERO
	queue_redraw()


func _drag(i: int, p: Vector2) -> void:
	if i != _joy_id:
		return
	var d := p - _joy_origin
	if d.length() > JOY_R:
		_joy_origin += d.normalized() * (d.length() - JOY_R)
		d = p - _joy_origin
	_joy_pos = p
	move = d / JOY_R
	queue_redraw()


func _draw() -> void:
	var font := ThemeDB.fallback_font
	var s := get_viewport_rect().size
	var base := _joy_origin if _joy_id != -1 else Vector2(170, s.y - 150)
	var knob := _joy_pos if _joy_id != -1 else base
	if _joy_id != -1:
		knob = base + (knob - base).limit_length(JOY_R)
	draw_circle(base, JOY_R, Color(1, 1, 1, 0.10))
	draw_arc(base, JOY_R, 0, TAU, 40, Color(1, 1, 1, 0.35), 3.0)
	draw_circle(knob, 38.0, Color(1, 1, 1, 0.30))
	for k in _btns:
		var b: Dictionary = _btns[k]
		var c: Vector2 = b["c"]
		var r: float = b["r"]
		var down: bool = _pressed.get(k, false)
		var col := Color("35C46A") if k == "shoot" else Color(1, 1, 1)
		draw_circle(c, r, Color(col.r, col.g, col.b, 0.45 if down else 0.18))
		draw_arc(c, r, 0, TAU, 32, Color(col.r, col.g, col.b, 0.8), 3.0)
		var fs := 18 if r >= 44.0 else 14
		draw_string(font, Vector2(c.x - r, c.y + fs * 0.35), str(b["t"]), HORIZONTAL_ALIGNMENT_CENTER, r * 2.0, fs, Color(1, 1, 1, 0.95))
