extends Control
## Volume and graphics quality. Low quality = 30 FPS cap and simpler pitch drawing.


func _ready() -> void:
	UI.background(self)
	var m := UI.margin(self, 40)
	var root := VBoxContainer.new()
	root.add_theme_constant_override("separation", 18)
	m.add_child(root)
	root.add_child(UI.label("Settings", 38, UI.ACCENT))
	root.add_child(UI.label("Sound volume", 24))
	var sl := HSlider.new()
	sl.min_value = 0.0
	sl.max_value = 1.0
	sl.step = 0.05
	sl.value = float(Game.settings["volume"])
	sl.custom_minimum_size = Vector2(600, 48)
	sl.value_changed.connect(_on_volume)
	sl.drag_ended.connect(_on_drag_ended)
	root.add_child(sl)
	root.add_child(UI.label("Graphics quality", 24))
	var opt := OptionButton.new()
	opt.add_item("Low (30 FPS, simple pitch)")
	opt.add_item("High (60 FPS)")
	opt.selected = int(Game.settings["quality"])
	opt.custom_minimum_size = Vector2(600, 60)
	opt.add_theme_font_size_override("font_size", 22)
	opt.item_selected.connect(_on_quality)
	root.add_child(opt)
	var note := UI.label("Career saves automatically after every match, training session and transfer.", 20, UI.MUTED)
	root.add_child(note)
	var spacer := Control.new()
	spacer.size_flags_vertical = Control.SIZE_EXPAND_FILL
	root.add_child(spacer)
	root.add_child(UI.button("Back", _back, true, Vector2(300, 64)))


func _on_volume(v: float) -> void:
	Game.settings["volume"] = v
	Game.apply_settings()


func _on_drag_ended(_changed: bool) -> void:
	Sfx.play_sound("kick")


func _on_quality(i: int) -> void:
	Game.settings["quality"] = i
	Game.apply_settings()


func _back() -> void:
	Game.save_settings()
	get_tree().change_scene_to_file("res://scenes/main_menu.tscn")
