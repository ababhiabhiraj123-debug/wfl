class_name UI
extends RefCounted
## Small helpers for building touch-friendly UI in code.

const BG := Color("101114")
const PANEL := Color("191C22")
const ACCENT := Color("35C46A")
const MUTED := Color("9AA3AF")


static func style(bg: Color, radius: int = 12) -> StyleBoxFlat:
	var s := StyleBoxFlat.new()
	s.bg_color = bg
	s.set_corner_radius_all(radius)
	s.content_margin_left = 16
	s.content_margin_right = 16
	s.content_margin_top = 10
	s.content_margin_bottom = 10
	return s


static func label(text: String, size: int = 22, color: Color = Color.WHITE) -> Label:
	var l := Label.new()
	l.text = text
	l.add_theme_font_size_override("font_size", size)
	l.add_theme_color_override("font_color", color)
	return l


static func button(text: String, cb: Callable, accent: bool = false, min_size: Vector2 = Vector2(0, 64)) -> Button:
	var b := Button.new()
	b.text = text
	b.custom_minimum_size = min_size
	b.add_theme_font_size_override("font_size", 22)
	var base: Color = ACCENT if accent else Color("2A2F3A")
	b.add_theme_stylebox_override("normal", style(base))
	b.add_theme_stylebox_override("hover", style(base.lightened(0.1)))
	b.add_theme_stylebox_override("pressed", style(base.darkened(0.15)))
	b.add_theme_stylebox_override("disabled", style(Color("22262E")))
	var fc: Color = Color.BLACK if accent else Color.WHITE
	b.add_theme_color_override("font_color", fc)
	b.add_theme_color_override("font_hover_color", fc)
	b.add_theme_color_override("font_pressed_color", fc)
	b.add_theme_color_override("font_disabled_color", Color("666B75"))
	if cb.is_valid():
		b.pressed.connect(cb)
	return b


static func background(parent: Control) -> void:
	var r := ColorRect.new()
	r.color = BG
	r.set_anchors_preset(Control.PRESET_FULL_RECT)
	parent.add_child(r)


static func margin(parent: Control, m: int = 24) -> MarginContainer:
	var c := MarginContainer.new()
	c.set_anchors_preset(Control.PRESET_FULL_RECT)
	for side in ["left", "right", "top", "bottom"]:
		c.add_theme_constant_override("margin_" + side, m)
	parent.add_child(c)
	return c


static func panel() -> PanelContainer:
	var p := PanelContainer.new()
	p.add_theme_stylebox_override("panel", style(PANEL))
	return p


## options: Array of [text, Callable]. The first option is drawn as the accent button.
## body: a String or a Control. Returns the overlay so callers can free it.
static func modal(parent: Node, title: String, body: Variant, options: Array, height: int = 0) -> Control:
	var layer := Control.new()
	layer.set_anchors_preset(Control.PRESET_FULL_RECT)
	layer.mouse_filter = Control.MOUSE_FILTER_STOP
	layer.process_mode = Node.PROCESS_MODE_ALWAYS
	var dim := ColorRect.new()
	dim.color = Color(0, 0, 0, 0.72)
	dim.set_anchors_preset(Control.PRESET_FULL_RECT)
	layer.add_child(dim)
	var center := CenterContainer.new()
	center.set_anchors_preset(Control.PRESET_FULL_RECT)
	layer.add_child(center)
	var p := panel()
	center.add_child(p)
	var v := VBoxContainer.new()
	v.add_theme_constant_override("separation", 12)
	p.add_child(v)
	v.add_child(label(title, 30, ACCENT))
	var scroll := ScrollContainer.new()
	scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	v.add_child(scroll)
	var h: int = height
	if body is String:
		var txt: String = body
		var l := label(txt, 22)
		l.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
		l.custom_minimum_size = Vector2(740, 0)
		scroll.add_child(l)
		if h == 0:
			h = clampi((txt.count("\n") + 1 + txt.length() / 55) * 30 + 10, 60, 380)
	elif body is Control:
		var ctl: Control = body
		scroll.add_child(ctl)
		if h == 0:
			h = 360
	scroll.custom_minimum_size = Vector2(780, h)
	var holder: Container
	if options.size() > 3:
		var g := GridContainer.new()
		g.columns = 2
		holder = g
	else:
		holder = HBoxContainer.new()
	holder.add_theme_constant_override("separation", 10)
	v.add_child(holder)
	var i := 0
	for o in options:
		var cb: Callable = o[1]
		var handler := func() -> void:
			layer.queue_free()
			if cb.is_valid():
				cb.call()
		var b := button(str(o[0]), handler, i == 0)
		b.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		holder.add_child(b)
		i += 1
	parent.add_child(layer)
	return layer
