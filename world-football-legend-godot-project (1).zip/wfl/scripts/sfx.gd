extends Node
## Tiny procedural sound effects so the game ships with no copyrighted audio.

var _sounds: Dictionary = {}
var _players: Array[AudioStreamPlayer] = []


func _ready() -> void:
	_sounds["whistle"] = _tone(2900.0, 0.55, true)
	_sounds["kick"] = _tone(170.0, 0.09, false)
	for i in 3:
		var p := AudioStreamPlayer.new()
		add_child(p)
		_players.append(p)


func play_sound(sound_name: String) -> void:
	if not _sounds.has(sound_name):
		return
	for p in _players:
		if not p.playing:
			p.stream = _sounds[sound_name]
			p.play()
			return


func _tone(freq: float, dur: float, vibrato: bool) -> AudioStreamWAV:
	var rate := 22050
	var n := int(rate * dur)
	var data := PackedByteArray()
	data.resize(n * 2)
	for i in n:
		var t := float(i) / rate
		var env := 1.0 - float(i) / n
		var f := freq
		if vibrato:
			f = freq * (1.0 + 0.04 * sin(t * 45.0))
		var s := sin(TAU * f * t) * env * 0.35
		data.encode_s16(i * 2, int(s * 32767.0))
	var w := AudioStreamWAV.new()
	w.format = AudioStreamWAV.FORMAT_16_BITS
	w.mix_rate = rate
	w.stereo = false
	w.data = data
	return w
