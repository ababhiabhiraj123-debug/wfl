extends Control
## Transfer offers, transfer requests and contract negotiation.

var root: VBoxContainer


func _ready() -> void:
	if Game.career.is_empty():
		get_tree().change_scene_to_file("res://scenes/main_menu.tscn")
		return
	UI.background(self)
	var m := UI.margin(self, 24)
	root = VBoxContainer.new()
	root.add_theme_constant_override("separation", 10)
	m.add_child(root)
	_build()


func _clear() -> void:
	for ch in root.get_children():
		root.remove_child(ch)
		ch.queue_free()


func _build() -> void:
	_clear()
	var c: Dictionary = Game.career
	root.add_child(UI.label("Transfers & contract", 34, UI.ACCENT))
	var cid: String = c["club_id"]
	var info := "Club: %s" % Game.club_name(cid)
	if cid != "":
		info += "   ·   %d / week   ·   %d year(s) left" % [int(c["wage"]), int(c["contract_years"])]
	var window := "OPEN" if Game.transfer_window_open() else "CLOSED"
	info += "   ·   Transfer window: %s" % window
	root.add_child(UI.label(info, 21, UI.MUTED))
	var sc := ScrollContainer.new()
	sc.size_flags_vertical = Control.SIZE_EXPAND_FILL
	sc.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	root.add_child(sc)
	var lv := VBoxContainer.new()
	lv.add_theme_constant_override("separation", 10)
	lv.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	sc.add_child(lv)
	var offers: Array = c["offers"]
	if offers.is_empty():
		lv.add_child(UI.label("No offers at the moment.", 24))
	var i := 0
	for o in offers:
		lv.add_child(_offer_card(i, o))
		i += 1
	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 8)
	root.add_child(row)
	var buttons := [
		["Request transfer", _request],
		["Extend contract", _extend.bind(false)],
		["Ask for higher wage", _extend.bind(true)],
		["Back", _back],
	]
	for b in buttons:
		var btn := UI.button(b[0], b[1], false, Vector2(0, 64))
		btn.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		row.add_child(btn)


func _offer_card(i: int, o: Dictionary) -> Control:
	var cl: Dictionary = Game.club(str(o["club_id"]))
	var p := UI.panel()
	var h := HBoxContainer.new()
	h.add_theme_constant_override("separation", 12)
	p.add_child(h)
	var v := VBoxContainer.new()
	v.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	h.add_child(v)
	v.add_child(UI.label("%s  (rating %d · %s)" % [cl["name"], int(cl["rating"]), cl["style"]], 24))
	v.add_child(UI.label("%d per week · %d-year contract" % [int(o["wage"]), int(o["years"])], 20, UI.MUTED))
	h.add_child(UI.button("Accept", _accept.bind(i), true, Vector2(150, 60)))
	h.add_child(UI.button("Reject", _reject.bind(i), false, Vector2(150, 60)))
	return p


func _accept(i: int) -> void:
	var msg := Game.accept_offer(i)
	UI.modal(self, "Transfer complete", msg, [["OK", _build]])


func _reject(i: int) -> void:
	Game.reject_offer(i)
	_build()


func _request() -> void:
	var msg := Game.request_transfer()
	UI.modal(self, "Agent", msg, [["OK", _build]])


func _extend(ask_more: bool) -> void:
	var msg := Game.negotiate_extension(ask_more)
	UI.modal(self, "Contract talks", msg, [["OK", _build]])


func _back() -> void:
	get_tree().change_scene_to_file("res://scenes/dashboard.tscn")
