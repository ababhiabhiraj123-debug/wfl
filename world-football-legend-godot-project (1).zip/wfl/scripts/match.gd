extends Node2D
## 2D top-down match engine.
## Team 0 = the player's club (attacks right). Team 1 = opponent (attacks left).

const PW := 1000.0
const PH := 640.0
const MARGIN := 70.0
const GOAL_W := 130.0
const BOX_D := 165.0
const BOX_H := 330.0
const REAL_SECONDS := 300.0
const PX_PER_M := 9.5

# Normalised 4-4-2: x = progress towards the opponent goal, y = width.
const FORMATION := [
	Vector2(0.04, 0.5), Vector2(0.22, 0.14), Vector2(0.20, 0.38), Vector2(0.20, 0.62), Vector2(0.22, 0.86),
	Vector2(0.50, 0.12), Vector2(0.45, 0.38), Vector2(0.45, 0.62), Vector2(0.50, 0.88),
	Vector2(0.72, 0.38), Vector2(0.72, 0.62),
]
const SLOT_ROLE := ["GK", "LB", "CB", "CB", "RB", "LMF", "CMF", "CMF", "RMF", "CF", "CF"]
const SLOT_NUM := [1, 3, 5, 4, 2, 11, 8, 6, 7, 10, 9]
const POS_SLOT := {"GK": 0, "LB": 1, "CB": 2, "RB": 4, "LMF": 5, "DMF": 6, "CMF": 7, "AMF": 6, "RMF": 8, "LWF": 9, "SS": 9, "RWF": 10, "CF": 10}


class Fb:
	var team := 0
	var slot := 0
	var norm := Vector2.ZERO
	var role := ""
	var pname := ""
	var num := 0
	var ovr := 60
	var spd := 60.0
	var pas := 60.0
	var sht := 60.0
	var tkl := 60.0
	var gk := 20.0
	var pos := Vector2.ZERO
	var vel := Vector2.ZERO
	var facing := Vector2.RIGHT
	var stamina := 100.0
	var stun := 0.0
	var freeze := 0.0
	var think := 0.5
	var tackle_cd := 0.0
	var yellow := 0
	var off := false
	var is_user := false


enum State { INTRO, PLAY, DEAD, BREAK, PAUSED, END }

var state: int = State.INTRO
var prev_state: int = State.PLAY
var players: Array[Fb] = []
var user_fb: Fb = null
var user_active := false
var user_off := false
var enter_minute := 0.0
var status_text := ""
var club_ids: Array = ["", ""]
var user_is_home := true
var team_color: Array = [Color.WHITE, Color.WHITE]
var team_style: Array = ["", ""]
var team_rating: Array = [60, 60]
var team_short: Array = ["", ""]
var score: Array = [0, 0]
var clock := 0.0
var added := 2.0
var half_done := false
var first_kick := 0
var time_s := 0.0
var ball_pos := Vector2(PW * 0.5, PH * 0.5)
var ball_vel := Vector2.ZERO
var carrier: Fb = null
var last_touch: Fb = null
var kicker: Fb = null
var kicker_t := 0.0
var dead_t := 0.0
var kickoff_pending := false
var restart_kind := ""
var restart_team := 0
var taker: Fb = null
var call_t := 0.0
var last_passer: Fb = null
var last_pass_time := -99.0
var pass_from: Fb = null
var rank: Array = [[], []]
var ref_pos := Vector2(PW * 0.5, PH * 0.5)
var slide_t := 0.0
var slide_hit := false
var slide_cd := 0.0
var skill_t := 0.0
var dribble_cd := 0.0
var tackle_cd := 0.0
var banner_t := 0.0
var cam_far := false
var quality := 1
var u_end_clock := -1.0
var ustats := {"goals": 0, "assists": 0, "passes": 0, "passes_ok": 0, "shots": 0, "tackles": 0, "distance": 0.0, "yellow": 0, "red": 0}
var rng: RandomNumberGenerator
var cam: Camera2D
var hud: Control
var lbl_score: Label
var lbl_banner: Label
var bar: ProgressBar
var touch: TouchControls
var font: Font


# ------------------------------------------------------------------ setup
func _ready() -> void:
	var pm: Dictionary = Game.pending_match
	if Game.career.is_empty() or pm.is_empty():
		get_tree().change_scene_to_file("res://scenes/main_menu.tscn")
		return
	rng = Game.rng
	font = ThemeDB.fallback_font
	quality = int(Game.settings["quality"])
	enter_minute = float(pm["enter"])
	status_text = str(pm["status"])
	user_is_home = pm["home"] == Game.career["club_id"]
	var opp: String = pm["away"] if user_is_home else pm["home"]
	club_ids = [str(Game.career["club_id"]), opp]
	for t in 2:
		var c: Dictionary = Game.club(str(club_ids[t]))
		team_color[t] = Color(str(c["color"]))
		team_style[t] = str(c["style"])
		team_rating[t] = int(c["rating"])
		team_short[t] = str(c["short"])
	var c0: Color = team_color[0]
	var c1: Color = team_color[1]
	if c0.distance_to(c1) < 0.4:
		team_color[1] = Color.WHITE
	added = float(rng.randi_range(1, 4))
	first_kick = 0 if user_is_home else 1
	_build_players()
	_build_camera()
	_build_hud()
	for f in players:
		f.pos = _formation_world(f.team, minf(f.norm.x, 0.46), f.norm.y)
	state = State.INTRO
	_show_intro()


func _build_players() -> void:
	var us: int = int(POS_SLOT.get(str(Game.career["pos"]), 10))
	for t in 2:
		var squad: Array = Game.squad_for(str(club_ids[t]))
		for s in 11:
			var f := Fb.new()
			f.team = t
			f.slot = s
			f.norm = FORMATION[s]
			f.role = SLOT_ROLE[s]
			f.num = SLOT_NUM[s]
			var base: int = clampi(int(team_rating[t]) + rng.randi_range(-6, 6), 38, 92)
			f.ovr = base
			f.spd = float(clampi(base + rng.randi_range(-8, 8), 30, 95))
			f.pas = float(clampi(base + rng.randi_range(-8, 8), 30, 95))
			f.sht = float(clampi(base + rng.randi_range(-8, 8), 30, 95))
			f.tkl = float(clampi(base + rng.randi_range(-8, 8), 30, 95))
			f.gk = float(base) if s == 0 else 20.0
			f.pname = str(squad[(s + t * 3) % squad.size()]["name"])
			players.append(f)
	user_fb = players[us]
	var a: Dictionary = Game.career["attrs"]
	user_fb.pname = str(Game.career["name"])
	user_fb.num = int(Game.career["shirt"])
	user_fb.role = str(Game.career["pos"])
	user_fb.ovr = Game.current_ovr()
	user_fb.spd = float(a["speed"])
	user_fb.pas = float(a["passing"])
	user_fb.sht = float(a["finishing"])
	user_fb.tkl = float(a["tackling"])
	user_fb.gk = float(a["goalkeeping"])
	user_fb.stamina = clampf(100.0 - float(Game.career["fatigue"]) * 0.45, 40.0, 100.0)


func _build_camera() -> void:
	cam = Camera2D.new()
	add_child(cam)
	cam.position_smoothing_enabled = true
	cam.position_smoothing_speed = 6.0
	cam.limit_left = int(-MARGIN)
	cam.limit_top = int(-MARGIN)
	cam.limit_right = int(PW + MARGIN)
	cam.limit_bottom = int(PH + MARGIN)
	cam.zoom = Vector2(1.35, 1.35)
	cam.position = Vector2(PW * 0.5, PH * 0.5)


func _build_hud() -> void:
	var tl := CanvasLayer.new()
	tl.layer = 4
	add_child(tl)
	touch = TouchControls.new()
	tl.add_child(touch)
	touch.action.connect(_on_action)
	var hl := CanvasLayer.new()
	hl.layer = 10
	add_child(hl)
	hud = Control.new()
	hud.set_anchors_preset(Control.PRESET_FULL_RECT)
	hud.mouse_filter = Control.MOUSE_FILTER_IGNORE
	hl.add_child(hud)
	var pc := PanelContainer.new()
	pc.add_theme_stylebox_override("panel", UI.style(Color(0, 0, 0, 0.6), 10))
	pc.mouse_filter = Control.MOUSE_FILTER_IGNORE
	hud.add_child(pc)
	pc.set_anchors_preset(Control.PRESET_CENTER_TOP)
	pc.grow_horizontal = Control.GROW_DIRECTION_BOTH
	lbl_score = UI.label("", 26)
	pc.add_child(lbl_score)
	lbl_banner = UI.label("", 54)
	lbl_banner.set_anchors_preset(Control.PRESET_FULL_RECT)
	lbl_banner.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	lbl_banner.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	lbl_banner.add_theme_color_override("font_outline_color", Color.BLACK)
	lbl_banner.add_theme_constant_override("outline_size", 10)
	lbl_banner.mouse_filter = Control.MOUSE_FILTER_IGNORE
	hud.add_child(lbl_banner)
	bar = ProgressBar.new()
	bar.custom_minimum_size = Vector2(170, 14)
	bar.position = Vector2(110, 24)
	bar.size = Vector2(170, 14)
	bar.show_percentage = false
	bar.min_value = 0
	bar.max_value = 100
	bar.add_theme_stylebox_override("fill", UI.style(UI.ACCENT, 4))
	bar.add_theme_stylebox_override("background", UI.style(Color(0, 0, 0, 0.5), 4))
	bar.mouse_filter = Control.MOUSE_FILTER_IGNORE
	hud.add_child(bar)


func _show_intro() -> void:
	var names: Array = []
	for f in players:
		if f.team == 0:
			names.append("%d %s" % [f.num, f.pname])
	var t := "%s · Round %d of %d\n" % [Game.world["league"], int(Game.career["round"]) + 1, Game.ROUNDS]
	var home_name: String = Game.club_name(str(club_ids[0 if user_is_home else 1]))
	var away_name: String = Game.club_name(str(club_ids[1 if user_is_home else 0]))
	t += "%s vs %s\nFormation: 4-4-2\n" % [home_name, away_name]
	if enter_minute <= 0.0:
		t += "Lineup: you START as %s.\n" % str(Game.career["pos"])
	else:
		t += "Lineup: you are a SUBSTITUTE. You come on around minute %d.\n" % int(enter_minute)
	t += "Starting XI: " + ", ".join(names) + "\n"
	t += "Opponent: %s · rating %d · style %s\n" % [Game.club_name(str(club_ids[1])), int(team_rating[1]), str(team_style[1])]
	t += "Manager: \"Play your game and impress me.\""
	UI.modal(hud, "Matchday", t, [["Kick off", _start_play]], 300)


func _start_play() -> void:
	if enter_minute <= 0.0:
		_activate_user()
	_kickoff(first_kick)


func _activate_user() -> void:
	if user_off:
		return
	user_active = true
	user_fb.is_user = true
	_show_banner("YOU'RE ON!", 1.5)


# ------------------------------------------------------------------ helpers
func _fw(team: int, nx: float, ny: float) -> Vector2:
	if team == 0:
		return Vector2(nx * PW, ny * PH)
	return Vector2((1.0 - nx) * PW, (1.0 - ny) * PH)


func _formation_world(team: int, nx: float, ny: float) -> Vector2:
	return _fw(team, nx, ny)


func _ball_frame(team: int) -> Vector2:
	if team == 0:
		return Vector2(ball_pos.x / PW, ball_pos.y / PH)
	return Vector2(1.0 - ball_pos.x / PW, 1.0 - ball_pos.y / PH)


func _goal_center(team: int) -> Vector2:
	return Vector2(PW, PH * 0.5) if team == 0 else Vector2(0.0, PH * 0.5)


func _speed(f: Fb) -> float:
	return (95.0 + f.spd * 0.55) * (0.78 + 0.22 * f.stamina / 100.0)


func _show_banner(text: String, secs: float) -> void:
	lbl_banner.text = text
	banner_t = secs


func _nearest_opp(f: Fb) -> Fb:
	var best: Fb = null
	var bd := 1e9
	for o in players:
		if o.team == f.team or o.off:
			continue
		var d := o.pos.distance_squared_to(f.pos)
		if d < bd:
			bd = d
			best = o
	return best


func _opp_dist(p: Vector2, team: int) -> float:
	var bd := 1e9
	for o in players:
		if o.team == team or o.off:
			continue
		bd = minf(bd, o.pos.distance_to(p))
	return bd


func _lane_risk(a: Vector2, b: Vector2, team: int) -> float:
	var n := 0.0
	for o in players:
		if o.team == team or o.off:
			continue
		var cp := Geometry2D.get_closest_point_to_segment(o.pos, a, b)
		if cp.distance_to(o.pos) < 26.0:
			n += 1.0
	return n


func _user_move() -> Vector2:
	var mv: Vector2 = touch.move
	if mv.length() < 0.05:
		mv = Input.get_vector("ui_left", "ui_right", "ui_up", "ui_down")
	return mv


# ------------------------------------------------------------------ main loop
func _physics_process(delta: float) -> void:
	if state == State.PLAY:
		_update_clock(delta)
		if state != State.PLAY:
			return
		if not user_active and not user_off and clock >= enter_minute:
			_activate_user()
		_update_ai(delta)
		if user_active:
			_update_user(delta)
		_update_ball(delta)
		_check_bounds()
		ref_pos = ref_pos.move_toward(ball_pos + Vector2(45, 35), 85.0 * delta)
	elif state == State.DEAD or state == State.BREAK or state == State.END:
		dead_t -= delta
		if dead_t <= 0.0:
			_dead_done()


func _process(delta: float) -> void:
	if hud == null:
		return
	banner_t -= delta
	if banner_t <= 0.0:
		lbl_banner.text = ""
	var minute := int(clock)
	var mtxt := "%d'" % minute
	if clock >= 90.0:
		mtxt = "90+%d'" % int(clock - 90.0)
	lbl_score.text = "%s  %d - %d  %s    %s" % [team_short[0], score[0], score[1], team_short[1], mtxt]
	bar.value = user_fb.stamina
	var focus := user_fb.pos if user_active else ball_pos
	cam.position = focus
	queue_redraw()


func _update_clock(delta: float) -> void:
	time_s += delta
	clock += delta * (90.0 / REAL_SECONDS)
	call_t = maxf(0.0, call_t - delta)
	dribble_cd = maxf(0.0, dribble_cd - delta)
	tackle_cd = maxf(0.0, tackle_cd - delta)
	slide_cd = maxf(0.0, slide_cd - delta)
	if not half_done and clock >= 45.0:
		half_done = true
		state = State.BREAK
		dead_t = 3.0
		kickoff_pending = true
		restart_team = 1 - first_kick
		_show_banner("HALF TIME", 3.0)
		Sfx.play_sound("whistle")
	elif clock >= 90.0 + added:
		state = State.END
		dead_t = 2.5
		u_end_clock = clock if u_end_clock < 0.0 else u_end_clock
		_show_banner("FULL TIME", 2.5)
		Sfx.play_sound("whistle")


func _dead_done() -> void:
	if state == State.END:
		_finish()
		return
	if kickoff_pending:
		_kickoff(restart_team)
		return
	state = State.PLAY


# ------------------------------------------------------------------ restarts
func _kickoff(team: int) -> void:
	kickoff_pending = false
	for f in players:
		f.pos = _formation_world(f.team, minf(f.norm.x, 0.46), f.norm.y)
		f.vel = Vector2.ZERO
		f.freeze = 0.0
		f.stun = 0.0
		f.facing = Vector2.RIGHT if f.team == 0 else Vector2.LEFT
	ball_pos = Vector2(PW * 0.5, PH * 0.5)
	ball_vel = Vector2.ZERO
	var tk: Fb = null
	for f in players:
		if f.team == team and f.slot == 10:
			tk = f
	tk.pos = Vector2(PW * 0.5 + (-8.0 if team == 0 else 8.0), PH * 0.5)
	taker = tk
	carrier = tk
	last_touch = tk
	tk.think = 0.7
	restart_kind = "kickoff"
	state = State.DEAD
	dead_t = 0.9
	if lbl_banner.text == "":
		_show_banner("KICK OFF", 0.9)


func _pick_taker(team: int, spot: Vector2, kind: String) -> Fb:
	var best: Fb = null
	var bd := 1e9
	for f in players:
		if f.team != team or f.off:
			continue
		if kind == "goal_kick":
			if f.slot == 0:
				return f
			continue
		if f.slot == 0:
			continue
		var d := f.pos.distance_squared_to(spot)
		if d < bd:
			bd = d
			best = f
	return best


func _restart(team: int, spot: Vector2, kind: String, text: String) -> void:
	restart_kind = kind
	restart_team = team
	state = State.DEAD
	dead_t = 1.6 if kind == "penalty" else 1.0
	ball_vel = Vector2.ZERO
	ball_pos = spot
	var tk: Fb = _pick_taker(team, spot, kind)
	if kind == "penalty":
		for f in players:
			if f.team == team and f.slot != 0 and not f.off and (tk == null or f.sht > tk.sht):
				if not (f.is_user and not user_active):
					tk = f
		if team == 0 and user_active and not user_off:
			tk = user_fb
	taker = tk
	tk.pos = spot
	tk.vel = Vector2.ZERO
	tk.facing = (Vector2(PW * 0.5, PH * 0.5) - spot).normalized()
	if kind == "penalty":
		tk.facing = (_goal_center(team) - spot).normalized()
		var px := PW - BOX_D - 40.0 if team == 0 else BOX_D + 40.0
		for f in players:
			if f == tk or f.off:
				continue
			f.freeze = 2.0
			f.vel = Vector2.ZERO
			if f.slot == 0:
				var gx := 25.0 if f.team == 0 else PW - 25.0
				f.pos = Vector2(gx, PH * 0.5)
			else:
				f.pos = Vector2(px + rng.randf_range(-20.0, 20.0), 130.0 + f.slot * 38.0 + (14.0 if f.team == 0 else 0.0))
	carrier = tk
	last_touch = tk
	tk.think = 0.8
	_show_banner(text, 1.2)
	Sfx.play_sound("whistle")


func _check_bounds() -> void:
	var p := ball_pos
	if p.x >= 0.0 and p.x <= PW and p.y >= 0.0 and p.y <= PH:
		return
	if last_touch == null:
		last_touch = players[0]
	if p.y < 0.0 or p.y > PH:
		var spot := Vector2(clampf(p.x, 25.0, PW - 25.0), 0.0 if p.y < 0.0 else PH)
		_restart(1 - last_touch.team, spot, "throw", "THROW-IN")
		return
	if absf(p.y - PH * 0.5) < GOAL_W * 0.5:
		_goal(0 if p.x > PW else 1)
		return
	var defending := 0 if p.x < 0.0 else 1
	if last_touch.team == defending:
		var cy := 0.0 if p.y < PH * 0.5 else PH
		var cx := 0.0 if p.x < 0.0 else PW
		_restart(1 - defending, Vector2(cx, cy), "corner", "CORNER")
	else:
		_restart(defending, Vector2(40.0 if p.x < 0.0 else PW - 40.0, PH * 0.5), "goal_kick", "GOAL KICK")


func _goal(scoring_team: int) -> void:
	score[scoring_team] += 1
	var scorer := last_touch
	var own: bool = scorer != null and scorer.team != scoring_team
	var text := "GOAL!"
	if own:
		text = "OWN GOAL"
	elif scorer != null:
		text += "  " + scorer.pname
		if scorer.is_user:
			ustats["goals"] += 1
		elif last_passer != null and last_passer.is_user and last_passer.team == scoring_team and time_s - last_pass_time < 6.0:
			ustats["assists"] += 1
	Sfx.play_sound("whistle")
	_show_banner(text, 3.0)
	state = State.DEAD
	dead_t = 3.0
	kickoff_pending = true
	restart_team = 1 - scoring_team
	carrier = null
	ball_vel = Vector2.ZERO
	ball_pos = Vector2(PW * 0.5, PH * 0.5)
	restart_kind = ""
	taker = null


# ------------------------------------------------------------------ fouls / tackles
func _try_tackle(tk: Fb, victim: Fb, sliding: bool) -> void:
	var p_win := clampf(0.40 + (tk.tkl - float(victim.ovr)) * 0.006 + (0.08 if sliding else 0.0), 0.15, 0.8)
	var p_foul := 0.10 + (0.12 if sliding else 0.0)
	var r := rng.randf()
	if r < p_foul:
		_foul(tk, victim)
	elif r < p_foul + p_win:
		last_touch = tk
		if tk.is_user:
			ustats["tackles"] += 1
		_take_ball(tk)
		victim.stun = 0.5
	else:
		tk.stun = 0.45


func _foul(offender: Fb, victim: Fb) -> void:
	var text := "FOUL"
	var r := rng.randf()
	if r < 0.04:
		offender.off = true
		text = "RED CARD · " + offender.pname
		if offender.is_user:
			ustats["red"] += 1
			user_active = false
			user_off = true
			offender.is_user = false
			u_end_clock = clock
	elif r < 0.20:
		offender.yellow += 1
		text = "YELLOW CARD · " + offender.pname
		if offender.is_user:
			ustats["yellow"] += 1
		if offender.yellow >= 2:
			offender.off = true
			text = "SECOND YELLOW · " + offender.pname
			if offender.is_user:
				ustats["red"] += 1
				user_active = false
				user_off = true
				offender.is_user = false
				u_end_clock = clock
	var in_box: bool = (victim.team == 0 and victim.pos.x > PW - BOX_D and absf(victim.pos.y - PH * 0.5) < BOX_H * 0.5) \
		or (victim.team == 1 and victim.pos.x < BOX_D and absf(victim.pos.y - PH * 0.5) < BOX_H * 0.5)
	if in_box:
		var pen := Vector2(PW - 110.0 if victim.team == 0 else 110.0, PH * 0.5)
		_restart(victim.team, pen, "penalty", "PENALTY! " + text)
	else:
		var spot := victim.pos.clamp(Vector2(15, 15), Vector2(PW - 15, PH - 15))
		_restart(victim.team, spot, "free_kick", text)


# ------------------------------------------------------------------ AI
func _target_for(f: Fb, team_ball: bool) -> Vector2:
	var bf := _ball_frame(f.team)
	var n := f.norm
	var style: String = team_style[f.team]
	if f.slot == 0:
		return _fw(f.team, 0.035, clampf(bf.y, 0.38, 0.62))
	var shift := (bf.x - 0.5) * 0.45
	if style == "possession" or style == "press":
		shift += 0.04
	elif style == "defensive":
		shift -= 0.07
	elif style == "counter" and not team_ball:
		shift -= 0.04
	if team_ball:
		if f.slot >= 5:
			shift += 0.10
		if style == "wing" and (f.slot == 1 or f.slot == 4):
			shift += 0.22
	elif f.slot >= 9:
		shift -= 0.05
	var max_x := 0.86 if f.slot >= 5 else 0.62
	var nx := clampf(n.x + shift, 0.08, max_x)
	var ny := lerpf(n.y, bf.y, 0.28)
	if style == "wing" and team_ball and (f.slot == 5 or f.slot == 8 or f.slot >= 9):
		ny = lerpf(ny, 0.08 if n.y < 0.5 else 0.92, 0.4)
	return _fw(f.team, nx, ny)


func _rank_ball() -> void:
	for t in 2:
		var arr: Array = []
		for f in players:
			if f.team == t and f.slot != 0 and not f.off and not f.is_user:
				arr.append(f)
		arr.sort_custom(func(a, b): return a.pos.distance_squared_to(ball_pos) < b.pos.distance_squared_to(ball_pos))
		rank[t] = arr


func _update_ai(delta: float) -> void:
	_rank_ball()
	for f in players:
		if f.off:
			continue
		f.stun = maxf(0.0, f.stun - delta)
		f.freeze = maxf(0.0, f.freeze - delta)
		f.tackle_cd = maxf(0.0, f.tackle_cd - delta)
		if f.is_user:
			continue
		if f.freeze > 0.0:
			f.vel = Vector2.ZERO
			continue
		_ai_think(f, delta)
	_separate()


func _separate() -> void:
	for i in players.size():
		var a := players[i]
		if a.off:
			continue
		for j in range(i + 1, players.size()):
			var b := players[j]
			if b.off:
				continue
			var d := a.pos - b.pos
			var l := d.length()
			if l < 14.0 and l > 0.01:
				var push := d / l * (14.0 - l) * 0.5
				if not a.is_user and a.freeze <= 0.0:
					a.pos += push
				if not b.is_user and b.freeze <= 0.0:
					b.pos -= push


func _move(f: Fb, target: Vector2, delta: float, mult: float) -> void:
	var to := target - f.pos
	var d := to.length()
	var sp := _speed(f) * mult
	if f.stun > 0.0:
		sp *= 0.35
	var desired := Vector2.ZERO
	if d > 3.0:
		desired = to / d * sp * minf(1.0, d / 45.0)
	f.vel = f.vel.lerp(desired, minf(1.0, 9.0 * delta))
	f.pos += f.vel * delta
	if f.vel.length() > 8.0:
		f.facing = f.vel.normalized()


func _ai_think(f: Fb, delta: float) -> void:
	if carrier == f:
		_ai_with_ball(f, delta)
		return
	if f.slot == 0:
		_gk_move(f, delta)
		return
	var mine: bool = carrier != null and carrier.team == f.team
	var target := _target_for(f, mine)
	var mult := 0.82
	var idx: int = (rank[f.team] as Array).find(f)
	if carrier == null:
		if idx >= 0 and idx < 2:
			target = ball_pos + ball_vel * 0.25
			mult = 1.0
	elif carrier.team != f.team:
		var n_chase := 2
		if team_style[f.team] == "press":
			n_chase = 3
		elif team_style[f.team] == "defensive":
			n_chase = 1
		if idx >= 0 and idx < n_chase:
			target = carrier.pos + carrier.vel * 0.25
			mult = 1.0
			if f.pos.distance_to(carrier.pos) < 20.0 and f.tackle_cd <= 0.0 and f.stun <= 0.0:
				f.tackle_cd = 1.3
				if rng.randf() < 0.55:
					_try_tackle(f, carrier, false)
	else:
		mult = 1.0 if f.slot >= 9 else 0.9
	_move(f, target, delta, mult)


func _gk_move(f: Fb, delta: float) -> void:
	var gx := 30.0 if f.team == 0 else PW - 30.0
	var ty := clampf(ball_pos.y, PH * 0.5 - 55.0, PH * 0.5 + 55.0)
	var target := Vector2(gx, ty)
	var mult := 0.9
	if carrier == null:
		var toward := (f.team == 0 and ball_vel.x < -150.0) or (f.team == 1 and ball_vel.x > 150.0)
		var in_box := (f.team == 0 and ball_pos.x < BOX_D) or (f.team == 1 and ball_pos.x > PW - BOX_D)
		in_box = in_box and absf(ball_pos.y - PH * 0.5) < BOX_H * 0.5
		if toward:
			var t := (gx - ball_pos.x) / ball_vel.x
			target.y = clampf(ball_pos.y + ball_vel.y * t, PH * 0.5 - 62.0, PH * 0.5 + 62.0)
			mult = 1.7
		elif in_box and ball_vel.length() < 90.0:
			target = ball_pos
			mult = 1.0
	_move(f, target, delta, mult)


func _ai_with_ball(f: Fb, delta: float) -> void:
	f.think -= delta
	if taker == f and restart_kind != "":
		if f.think <= 0.0:
			_ai_set_piece(f)
		return
	if f.slot == 0:
		if f.think <= 0.0:
			_ai_pass(f, true)
		return
	var goal := _goal_center(f.team)
	var to_goal := goal - f.pos
	var dist_goal := to_goal.length()
	var dir := to_goal.normalized()
	var opp := _nearest_opp(f)
	var pressured := false
	if opp != null:
		var od := opp.pos.distance_to(f.pos)
		if od < 70.0:
			pressured = true
			dir = (dir - (opp.pos - f.pos).normalized() * 0.9).normalized()
	_move(f, f.pos + dir * 120.0, delta, 0.88)
	if f.think <= 0.0:
		f.think = rng.randf_range(0.3, 0.75)
		var shoot_p := 0.0
		if dist_goal < 190.0:
			shoot_p = 0.6
		elif dist_goal < 300.0:
			shoot_p = 0.22
		if rng.randf() < shoot_p:
			_shoot(f, Vector2.ZERO)
			return
		var pass_p := 0.25
		if pressured:
			pass_p = 0.7
		if team_style[f.team] == "possession":
			pass_p += 0.25
		if rng.randf() < pass_p:
			_ai_pass(f, false)


func _ai_set_piece(f: Fb) -> void:
	if restart_kind == "corner":
		var target := Vector2(PW - 110.0 if f.team == 0 else 110.0, PH * 0.5 + rng.randf_range(-50.0, 50.0))
		_register_pass(f)
		_kick_to(f, target, 470.0)
	elif restart_kind == "penalty":
		_shoot(f, Vector2.ZERO)
	elif restart_kind == "goal_kick":
		_ai_pass(f, true)
	else:
		_ai_pass(f, false)


func _ai_pass(f: Fb, long_ball: bool) -> void:
	var best: Fb = null
	var best_s := -1e9
	var attack_dir := 1.0 if f.team == 0 else -1.0
	var counter: bool = team_style[f.team] == "counter"
	var possession: bool = team_style[f.team] == "possession"
	for t in players:
		if t.team != f.team or t == f or t.off:
			continue
		var d := t.pos.distance_to(f.pos)
		if d < 50.0 or d > (650.0 if long_ball else 420.0):
			continue
		var gain := (t.pos.x - f.pos.x) * attack_dir
		var open := minf(_opp_dist(t.pos, f.team), 140.0)
		var risk := _lane_risk(f.pos, t.pos, f.team)
		var s := gain * (0.9 if counter else 0.6) + open * 0.8 - risk * 120.0 - d * (0.3 if possession else 0.12)
		if t.is_user and user_active and call_t > 0.0:
			s += 120.0
		if long_ball:
			s += d * 0.2
		if t.slot == 0:
			s -= 200.0
		if s > best_s:
			best_s = s
			best = t
	if best == null:
		_kick_to(f, f.pos + Vector2(attack_dir * 200.0, rng.randf_range(-100.0, 100.0)), 380.0)
		return
	_register_pass(f)
	var lead := best.pos + best.vel * 0.45
	_kick_to(f, lead, clampf(lead.distance_to(f.pos) * 1.7 + 140.0, 240.0, 560.0))


# ------------------------------------------------------------------ ball
func _register_pass(f: Fb) -> void:
	last_passer = f
	last_pass_time = time_s
	if f.is_user:
		ustats["passes"] += 1
		pass_from = f


func _kick_ball(f: Fb, v: Vector2) -> void:
	carrier = null
	ball_vel = v
	kicker = f
	kicker_t = 0.35
	last_touch = f
	if taker == f:
		restart_kind = ""
		taker = null
	Sfx.play_sound("kick")


func _kick_to(f: Fb, target: Vector2, speed: float) -> void:
	var dir := (target - f.pos).normalized()
	var err := rng.randfn(0.0, (100.0 - f.pas) * 0.0025)
	_kick_ball(f, dir.rotated(err) * speed)


func _shoot(f: Fb, aim: Vector2) -> void:
	var goal := _goal_center(f.team)
	var ty := PH * 0.5
	if aim == Vector2.ZERO:
		ty += rng.randf_range(-0.8, 0.8) * GOAL_W * 0.45
	else:
		ty += clampf(aim.y, -1.0, 1.0) * GOAL_W * 0.42
	var target := Vector2(goal.x + (10.0 if f.team == 0 else -10.0), ty)
	var dir := (target - f.pos).normalized()
	if f.is_user and f.facing.dot(dir) < 0.0:
		dir = f.facing
	var dist := f.pos.distance_to(goal)
	var err := rng.randfn(0.0, (100.0 - f.sht) * 0.0032 + 0.02 + dist / 4000.0)
	_kick_ball(f, dir.rotated(err) * (560.0 + f.sht * 2.0))
	if f.is_user:
		ustats["shots"] += 1


func _take_ball(f: Fb) -> void:
	carrier = f
	last_touch = f
	ball_vel = Vector2.ZERO
	f.think = rng.randf_range(0.2, 0.5)
	if pass_from != null and f != pass_from:
		if f.team == pass_from.team:
			ustats["passes_ok"] += 1
		pass_from = null


func _update_ball(delta: float) -> void:
	kicker_t = maxf(0.0, kicker_t - delta)
	if carrier != null:
		ball_pos = carrier.pos + carrier.facing * 13.0
		ball_vel = carrier.vel
		return
	ball_pos += ball_vel * delta
	ball_vel *= exp(-0.85 * delta)
	if ball_vel.length() < 8.0:
		ball_vel = Vector2.ZERO
	var best: Fb = null
	var best_d := 1e9
	for f in players:
		if f.off or f.freeze > 0.0:
			continue
		if f == kicker and kicker_t > 0.0:
			continue
		var reach := 26.0 if f.slot == 0 else 17.0
		var d := f.pos.distance_to(ball_pos)
		if d < reach and d < best_d:
			best = f
			best_d = d
	if best == null:
		return
	var sp := ball_vel.length()
	if best.slot == 0 and sp > 200.0:
		var p := 0.30 + best.gk * 0.0065 - sp * 0.0003
		if rng.randf() < p:
			_take_ball(best)
			Sfx.play_sound("kick")
		else:
			ball_vel = ball_vel.rotated(rng.randf_range(-1.0, 1.0)) * 0.45
			kicker = best
			kicker_t = 0.25
			last_touch = best
		return
	if sp > 420.0:
		ball_vel *= 0.55
		kicker = best
		kicker_t = 0.2
		last_touch = best
		return
	if sp > 200.0 and rng.randf() > 0.62 + best.pas * 0.003:
		ball_vel = ball_vel.rotated(rng.randf_range(-0.8, 0.8)) * 0.5
		kicker = best
		kicker_t = 0.2
		last_touch = best
		return
	_take_ball(best)


# ------------------------------------------------------------------ user
func _update_user(delta: float) -> void:
	var u := user_fb
	if u.freeze > 0.0:
		return
	var mv := _user_move()
	var spr: bool = touch.sprint or Input.is_key_pressed(KEY_SHIFT)
	var base := _speed(u)
	if slide_t > 0.0:
		slide_t -= delta
		u.pos += u.vel * delta
		u.vel *= exp(-2.5 * delta)
		if carrier != null and carrier.team != 0 and not slide_hit and u.pos.distance_to(carrier.pos) < 28.0:
			slide_hit = true
			_try_tackle(u, carrier, true)
		if slide_t <= 0.0:
			u.stun = 0.5
		return
	var target := Vector2.ZERO
	var running := mv.length() > 0.12
	if running:
		var sp := base * (1.28 if spr and u.stamina > 4.0 else 1.0)
		if u.stun > 0.0:
			sp *= 0.35
		target = mv.normalized() * sp * minf(1.0, mv.length() * 1.3)
		u.facing = mv.normalized()
	if skill_t > 0.0:
		skill_t -= delta
	else:
		u.vel = u.vel.lerp(target, minf(1.0, 11.0 * delta))
	u.pos += u.vel * delta
	u.pos = u.pos.clamp(Vector2(-25, -25), Vector2(PW + 25, PH + 25))
	if spr and running and u.stamina > 4.0:
		u.stamina -= 16.0 * delta
	else:
		u.stamina += 3.5 * delta
	u.stamina = clampf(u.stamina - u.vel.length() / 150.0 * 1.2 * delta, 0.0, 100.0)
	ustats["distance"] += u.vel.length() * delta / PX_PER_M


func _unhandled_key_input(event: InputEvent) -> void:
	var k := event as InputEventKey
	if k == null or not k.pressed or k.echo:
		return
	match k.keycode:
		KEY_Z: _on_action(&"pass")
		KEY_X: _on_action(&"shoot")
		KEY_C: _on_action(&"through")
		KEY_V: _on_action(&"tackle")
		KEY_B: _on_action(&"dribble")
		KEY_ESCAPE: _on_action(&"pause")


func _on_action(a: StringName) -> void:
	var act := str(a)
	if act == "pause":
		_pause()
		return
	if act == "cam":
		cam_far = not cam_far
		cam.zoom = Vector2(0.95, 0.95) if cam_far else Vector2(1.35, 1.35)
		return
	if state != State.PLAY or not user_active:
		return
	var u := user_fb
	var mv := _user_move()
	if act == "pass":
		if carrier == u:
			_user_pass(false)
		else:
			call_t = 1.5
	elif act == "through":
		if carrier == u:
			_user_pass(true)
	elif act == "shoot":
		if carrier == u:
			_shoot(u, mv)
	elif act == "tackle":
		if carrier != null and carrier.team == 1 and u.pos.distance_to(carrier.pos) < 38.0 and tackle_cd <= 0.0:
			tackle_cd = 0.8
			_try_tackle(u, carrier, false)
		elif (carrier == null or carrier.team == 1) and slide_cd <= 0.0 and slide_t <= 0.0:
			slide_cd = 1.5
			slide_t = 0.4
			slide_hit = false
			var dir := mv.normalized() if mv.length() > 0.2 else u.facing
			u.vel = dir * _speed(u) * 2.0
	elif act == "dribble":
		if carrier == u and dribble_cd <= 0.0:
			dribble_cd = 1.2
			skill_t = 0.25
			var dir2 := mv.normalized() if mv.length() > 0.2 else u.facing
			u.vel = dir2 * _speed(u) * 1.8
			for o in players:
				if o.team == 1 and not o.off and o.pos.distance_to(u.pos) < 45.0 and rng.randf() < 0.6:
					o.stun = 0.7


func _user_pass(through: bool) -> void:
	var u := user_fb
	var aim := _user_move()
	if aim.length() < 0.2:
		aim = u.facing
	aim = aim.normalized()
	var best: Fb = null
	var best_s := -1e9
	for t in players:
		if t.team != 0 or t == u or t.off:
			continue
		var to := t.pos - u.pos
		var d := to.length()
		if d < 40.0 or d > 700.0:
			continue
		var cos_a := to.normalized().dot(aim)
		if cos_a < (0.55 if through else 0.7):
			continue
		var s := cos_a * 100.0 - d * 0.1 - _lane_risk(u.pos, t.pos, 0) * 40.0
		if through:
			s = (t.pos.x - u.pos.x) * 0.5 + cos_a * 60.0 - _lane_risk(u.pos, t.pos, 0) * 50.0
		if t.slot == 0:
			s -= 150.0
		if s > best_s:
			best_s = s
			best = t
	_register_pass(u)
	if best == null:
		if u.pos.x > PW - 260.0 and (u.pos.y < 140.0 or u.pos.y > PH - 140.0):
			_kick_to(u, Vector2(PW - 120.0, PH * 0.5 + rng.randf_range(-40.0, 40.0)), 500.0)
		else:
			_kick_to(u, u.pos + aim * 220.0, 330.0)
		return
	var lead := best.pos + best.vel * (0.7 if through else 0.35)
	if through:
		lead += Vector2(70.0, 0.0)
	var dist := lead.distance_to(u.pos)
	var spd := clampf(dist * (2.0 if through else 1.7) + 140.0, 240.0, 620.0 if through else 560.0)
	_kick_to(u, lead, spd)


# ------------------------------------------------------------------ pause / finish
func _pause() -> void:
	if state == State.PAUSED or state == State.INTRO:
		return
	prev_state = state
	state = State.PAUSED
	touch.release_all()
	UI.modal(hud, "Paused", "Match paused.", [["Resume", _resume], ["Quit match (not counted)", _quit_match]])


func _resume() -> void:
	state = prev_state


func _quit_match() -> void:
	Game.pending_match = {}
	get_tree().change_scene_to_file("res://scenes/dashboard.tscn")


func _finish() -> void:
	var end_clock := u_end_clock if u_end_clock >= 0.0 else 90.0
	var minutes := 0
	if enter_minute < 90.0:
		minutes = int(clampf(minf(end_clock, 90.0) - enter_minute, 0.0, 90.0))
	var passes: int = int(ustats["passes"])
	var acc := 1.0 if passes == 0 else float(ustats["passes_ok"]) / float(passes)
	var won: bool = score[0] > score[1]
	var lost: bool = score[0] < score[1]
	var rating := 6.0 + int(ustats["goals"]) * 0.9 + int(ustats["assists"]) * 0.6 + (acc - 0.7) * 1.5 \
		+ int(ustats["tackles"]) * 0.18 + int(ustats["shots"]) * 0.05 - int(ustats["yellow"]) * 0.3 - int(ustats["red"]) * 1.5
	rating += 0.4 if won else (-0.3 if lost else 0.0)
	if minutes < 45:
		rating = lerpf(6.4, rating, float(minutes) / 45.0)
	rating = snappedf(clampf(rating, 3.5, 10.0), 0.1)
	var u := {
		"minutes": minutes, "rating": rating, "goals": ustats["goals"], "assists": ustats["assists"],
		"passes": ustats["passes"], "passes_ok": ustats["passes_ok"], "shots": ustats["shots"],
		"tackles": ustats["tackles"], "distance": ustats["distance"], "yellow": ustats["yellow"], "red": ustats["red"],
	}
	var hg: int = score[0] if user_is_home else score[1]
	var ag: int = score[1] if user_is_home else score[0]
	var home_id: String = str(club_ids[0]) if user_is_home else str(club_ids[1])
	var away_id: String = str(club_ids[1]) if user_is_home else str(club_ids[0])
	var res := {"home": home_id, "away": away_id, "hg": hg, "ag": ag, "user": u, "status": status_text}
	Game.pending_match = {}
	Game.finish_match(res)
	get_tree().change_scene_to_file("res://scenes/dashboard.tscn")


# ------------------------------------------------------------------ drawing
func _draw() -> void:
	if players.is_empty():
		return
	draw_rect(Rect2(-MARGIN, -MARGIN, PW + MARGIN * 2.0, PH + MARGIN * 2.0), Color("2E7D3A"))
	if quality > 0:
		for i in 12:
			if i % 2 == 0:
				draw_rect(Rect2(i * PW / 12.0, 0, PW / 12.0, PH), Color("33863F"))
	var line := Color(1, 1, 1, 0.85)
	var mid := Vector2(PW * 0.5, PH * 0.5)
	draw_rect(Rect2(0, 0, PW, PH), line, false, 3.0)
	draw_line(Vector2(PW * 0.5, 0), Vector2(PW * 0.5, PH), line, 3.0)
	draw_arc(mid, 82.0, 0, TAU, 48, line, 3.0)
	draw_circle(mid, 4.0, line)
	draw_rect(Rect2(0, PH * 0.5 - BOX_H * 0.5, BOX_D, BOX_H), line, false, 3.0)
	draw_rect(Rect2(PW - BOX_D, PH * 0.5 - BOX_H * 0.5, BOX_D, BOX_H), line, false, 3.0)
	draw_rect(Rect2(0, PH * 0.5 - 90.0, 55.0, 180.0), line, false, 3.0)
	draw_rect(Rect2(PW - 55.0, PH * 0.5 - 90.0, 55.0, 180.0), line, false, 3.0)
	draw_circle(Vector2(110, PH * 0.5), 3.0, line)
	draw_circle(Vector2(PW - 110, PH * 0.5), 3.0, line)
	draw_rect(Rect2(-24, PH * 0.5 - GOAL_W * 0.5, 24, GOAL_W), Color(1, 1, 1, 0.35))
	draw_rect(Rect2(PW, PH * 0.5 - GOAL_W * 0.5, 24, GOAL_W), Color(1, 1, 1, 0.35))
	for f in players:
		if f.off:
			continue
		var col: Color = team_color[f.team]
		if f.slot == 0:
			col = Color("F5C542") if f.team == 0 else Color("9B59B6")
		draw_circle(f.pos + Vector2(2, 3), 11.0, Color(0, 0, 0, 0.25))
		draw_circle(f.pos, 10.0, col)
		draw_arc(f.pos, 10.0, 0, TAU, 20, Color(0, 0, 0, 0.6), 2.0)
		draw_circle(f.pos + f.facing * 7.0, 3.0, Color(1, 1, 1, 0.9))
		if quality > 0:
			draw_string(font, f.pos + Vector2(-10, -15), str(f.num), HORIZONTAL_ALIGNMENT_CENTER, 20, 11, Color(1, 1, 1, 0.9))
	var ring := Color("35C46A") if user_active else Color(0.21, 0.77, 0.42, 0.45)
	draw_arc(user_fb.pos, 17.0, 0, TAU, 28, ring, 3.0)
	draw_string(font, user_fb.pos + Vector2(-50, -28), user_fb.pname, HORIZONTAL_ALIGNMENT_CENTER, 100, 13, Color("35C46A"))
	draw_circle(ref_pos, 8.0, Color("222222"))
	draw_arc(ref_pos, 8.0, 0, TAU, 16, Color("F2C400"), 2.0)
	var lx := clampf(ball_pos.x, 60.0, PW - 60.0)
	draw_circle(Vector2(lx, -14.0), 6.0, Color("F28C28"))
	draw_circle(Vector2(lx, PH + 14.0), 6.0, Color("F28C28"))
	draw_circle(ball_pos + Vector2(2, 3), 6.0, Color(0, 0, 0, 0.3))
	draw_circle(ball_pos, 6.0, Color.WHITE)
	draw_arc(ball_pos, 6.0, 0, TAU, 14, Color.BLACK, 1.5)
