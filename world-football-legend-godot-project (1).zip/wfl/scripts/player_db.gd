extends Control
## Browse the world database; edit club ratings offline (saved to user://world_import.json).

var ids: Array = []
var club_opt: OptionButton
var spin: SpinBox
var grid_holder: VBoxContainer


func _ready() -> void:
	UI.background(self)
	var m := UI.margin(self, 24)
	var root := VBoxContainer.new()
	root.add_theme_constant_override("separation", 10)
	m.add_child(root)
	root.add_child(UI.label("Player database", 34, UI.ACCENT))
	var info := UI.label("Last updated: %s\n%s" % [Game.world.get("last_updated", "?"), Game.world.get("source", "")], 17, UI.MUTED)
	info.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	info.custom_minimum_size = Vector2(1100, 0)
	root.add_child(info)
	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 10)
	root.add_child(row)
	club_opt = OptionButton.new()
	club_opt.custom_minimum_size = Vector2(380, 60)
	club_opt.add_theme_font_size_override("font_size", 22)
	for c in Game.world["clubs"]:
		ids.append(str(c["id"]))
		club_opt.add_item("%s (%d)" % [c["name"], int(c["rating"])])
	club_opt.item_selected.connect(_populate)
	row.add_child(club_opt)
	row.add_child(UI.label("Club rating:", 22))
	spin = SpinBox.new()
	spin.min_value = 30
	spin.max_value = 95
	spin.custom_minimum_size = Vector2(160, 60)
	row.add_child(spin)
	row.add_child(UI.button("Save rating edit", _save_edit, false, Vector2(240, 60)))
	var sc := ScrollContainer.new()
	sc.size_flags_vertical = Control.SIZE_EXPAND_FILL
	sc.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	root.add_child(sc)
	grid_holder = VBoxContainer.new()
	grid_holder.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	sc.add_child(grid_holder)
	root.add_child(UI.button("Back", _back, false, Vector2(0, 64)))
	_populate(0)


func _populate(idx: int) -> void:
	for ch in grid_holder.get_children():
		grid_holder.remove_child(ch)
		ch.queue_free()
	var id: String = ids[idx]
	var c: Dictionary = Game.club(id)
	spin.value = int(c["rating"])
	grid_holder.add_child(UI.label("%s · style %s · rating %d" % [c["name"], c["style"], int(c["rating"])], 22, UI.ACCENT))
	var g := GridContainer.new()
	g.columns = 4
	g.add_theme_constant_override("h_separation", 40)
	for h in ["Name", "Pos", "Age", "OVR"]:
		g.add_child(UI.label(h, 20, UI.MUTED))
	for p in Game.squad_for(id):
		for v in [str(p["name"]), str(p["pos"]), str(int(p["age"])), str(int(p["ovr"]))]:
			g.add_child(UI.label(v, 20))
	if not Game.career.is_empty() and Game.career["club_id"] == id:
		for v in [str(Game.career["name"]) + " (you)", str(Game.career["pos"]), str(int(Game.career["age"])), str(Game.current_ovr())]:
			g.add_child(UI.label(v, 20, UI.ACCENT))
	grid_holder.add_child(g)


func _save_edit() -> void:
	var id: String = ids[club_opt.selected]
	for c in Game.world["clubs"]:
		if c["id"] == id:
			c["rating"] = int(spin.value)
	Game.world["last_updated"] = Time.get_date_string_from_system()
	Game.save_world_edits()
	var sel := club_opt.selected
	club_opt.set_item_text(sel, "%s (%d)" % [Game.club(id)["name"], int(spin.value)])
	_populate(sel)
	UI.modal(self, "Saved", "Club rating saved to your local database.", [["OK", Callable()]])


func _back() -> void:
	get_tree().change_scene_to_file("res://scenes/main_menu.tscn")
