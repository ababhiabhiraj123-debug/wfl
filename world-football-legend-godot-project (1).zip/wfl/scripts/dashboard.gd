extends Control
## Career dashboard: profile, next match, training, table, stats, news.

var content: Control


func _ready() -> void:
	if Game.career.is_empty():
		get_tree().change_scene_to_file("res://scenes/main_menu.tscn")
		return
	UI.background(self)
	_build()
	_show_result()


func _build() -> void:
	if content != null:
		content.hide()
		content.queue_free()
	content = Control.new()
	content.set_anchors_preset(Control.PRESET_FULL_RECT)
	add_child(content)
	move_child(content, 1)
	var c: Dictionary = Game.career
	var cid: String = c["club_id"]
	var m := UI.margin(content, 18)
	var root := VBoxContainer.new()
	root.add_theme_constant_override("separation", 10)
	m.add_child(root)
	var head := "%s   ·   Season %s   ·   Round %d of %d" % [Game.club_name(cid), Game.season_label(), mini(int(c["round"]) + 1, Game.ROUNDS), Game.ROUNDS]
	root.add_child(UI.label(head, 22, UI.MUTED))
	var mid := HBoxContainer.new()
	mid.add_theme_constant_override("separation", 12)
	mid.size_flags_vertical = Control.SIZE_EXPAND_FILL
	root.add_child(mid)
	mid.add_child(_profile_panel())
	mid.add_child(_match_panel())
	mid.add_child(_news_panel())
	var bottom := HBoxContainer.new()
	bottom.add_theme_constant_override("separation", 8)
	root.add_child(bottom)
	var offers: int = (c["offers"] as Array).size()
	var tr_text := "Transfers" if offers == 0 else "Transfers (%d)" % offers
	for entry in [["League table", _table], ["Stats", _stats], [tr_text, _transfers], ["Save", _save], ["Menu", _menu]]:
		var b := UI.button(entry[0], entry[1], false, Vector2(0, 60))
		b.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		bottom.add_child(b)


func _profile_panel() -> Control:
	var c: Dictionary = Game.career
	var p := UI.panel()
	p.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	p.size_flags_stretch_ratio = 1.0
	var v := VBoxContainer.new()
	v.add_theme_constant_override("separation", 4)
	p.add_child(v)
	var top := HBoxContainer.new()
	v.add_child(top)
	var look: Dictionary = c["look"]
	var av := Avatar.new()
	av.custom_minimum_size = Vector2(110, 110)
	av.setup(Avatar.SKINS[int(look["skin"])], Avatar.HAIRS[int(look["hair"])], int(look["style"]))
	top.add_child(av)
	var nm := VBoxContainer.new()
	top.add_child(nm)
	nm.add_child(UI.label(str(c["name"]), 28))
	nm.add_child(UI.label("%s · Age %d · #%d" % [c["pos"], int(c["age"]), int(c["shirt"])], 20, UI.MUTED))
	nm.add_child(UI.label("%s · %s" % [c["nat"], Game.squad_status()], 20, UI.MUTED))
	v.add_child(UI.label("OVERALL  %d" % Game.current_ovr(), 44, UI.ACCENT))
	var form: Array = c["form"]
	var fa := 0.0
	for r in form:
		fa += float(r)
	var form_txt := "-" if form.is_empty() else "%.1f" % (fa / form.size())
	v.add_child(UI.label("Form (last 5): %s" % form_txt, 20))
	v.add_child(UI.label("Fatigue %d%%   Morale %d%%" % [int(c["fatigue"]), int(c["morale"])], 20))
	v.add_child(UI.label("Manager trust %d%%   Fans %d%%" % [int(c["trust"]), int(c["fans"])], 20))
	if str(c["club_id"]) != "":
		v.add_child(UI.label("Contract: %d yr(s) · %d / week" % [int(c["contract_years"]), int(c["wage"])], 20, UI.MUTED))
	if int(c["injury_weeks"]) > 0:
		v.add_child(UI.label("INJURED: %d week(s)" % int(c["injury_weeks"]), 20, Color("E5534B")))
	return p


func _match_panel() -> Control:
	var c: Dictionary = Game.career
	var p := UI.panel()
	p.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	var v := VBoxContainer.new()
	v.add_theme_constant_override("separation", 8)
	p.add_child(v)
	v.add_child(UI.label("NEXT MATCH", 20, UI.MUTED))
	var cid: String = c["club_id"]
	if cid == "":
		v.add_child(UI.label("No club", 30))
		v.add_child(UI.label("You are a free agent. Check offers in Transfers, or wait a week.", 20, UI.MUTED))
		var spacer0 := Control.new()
		spacer0.size_flags_vertical = Control.SIZE_EXPAND_FILL
		v.add_child(spacer0)
		v.add_child(UI.button("Wait a week", _play, true))
	else:
		var nm: Dictionary = Game.next_match()
		var home: bool = nm["home"] == cid
		var opp_id: String = nm["away"] if home else nm["home"]
		var oc: Dictionary = Game.club(opp_id)
		v.add_child(UI.label("%s (%s)" % [oc["name"], "H" if home else "A"], 30))
		v.add_child(UI.label("%s · rating %d · %s style" % [Game.world["league"], int(oc["rating"]), oc["style"]], 20, UI.MUTED))
		var pos := Game.position_of(cid)
		var row: Dictionary = Game.career["table"][cid]
		v.add_child(UI.label("League: %s of %d · %d pts" % [Game.ordinal(pos), Game.club_ids().size(), int(row["pts"])], 22))
		v.add_child(UI.label("Your status: %s" % Game.squad_status(), 22, UI.ACCENT))
		var spacer := Control.new()
		spacer.size_flags_vertical = Control.SIZE_EXPAND_FILL
		v.add_child(spacer)
		var play_text := "Play match" if int(c["injury_weeks"]) == 0 else "Simulate (injured)"
		v.add_child(UI.button(play_text, _play, true))
	var tb := UI.button("Training done this week" if c["training_done"] else "Training", _train, false)
	tb.disabled = bool(c["training_done"])
	v.add_child(tb)
	return p


func _news_panel() -> Control:
	var p := UI.panel()
	p.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	var v := VBoxContainer.new()
	v.add_theme_constant_override("separation", 6)
	p.add_child(v)
	v.add_child(UI.label("NEWS & MESSAGES", 20, UI.MUTED))
	var sc := ScrollContainer.new()
	sc.size_flags_vertical = Control.SIZE_EXPAND_FILL
	sc.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	v.add_child(sc)
	var nv := VBoxContainer.new()
	nv.add_theme_constant_override("separation", 8)
	nv.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	sc.add_child(nv)
	for n in Game.career["news"]:
		var l := UI.label("• " + str(n), 19)
		l.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
		l.custom_minimum_size = Vector2(300, 0)
		nv.add_child(l)
	return p


# ------------------------------------------------------------------ actions
func _play() -> void:
	var c: Dictionary = Game.career
	if str(c["club_id"]) == "":
		Game.advance_round("", "")
		Game.add_news("You waited for calls and trained alone.")
		Game.save_career()
		_build()
		_show_summary()
		return
	var nm: Dictionary = Game.next_match()
	if nm.is_empty():
		return
	var role: Dictionary = Game.match_role()
	if float(role["enter"]) >= 90.0:
		var status := str(role["status"])
		UI.modal(self, status, "You will not feature in this match. The result will be simulated.", [["Simulate", _sim_user.bind(status)]])
		return
	Game.pending_match = {"home": nm["home"], "away": nm["away"], "enter": role["enter"], "status": role["status"]}
	get_tree().change_scene_to_file("res://scenes/match.tscn")


func _sim_user(status: String) -> void:
	Game.sim_user_match(status)
	_build()
	_show_result()


func _show_result() -> void:
	var r: Dictionary = Game.last_result
	if r.is_empty():
		_show_summary()
		return
	Game.last_result = {}
	var res: Dictionary = r["res"]
	var u: Dictionary = res["user"]
	var t := "%s  %d - %d  %s\n" % [Game.club_name(str(res["home"])), int(res["hg"]), int(res["ag"]), Game.club_name(str(res["away"]))]
	if int(u["minutes"]) > 0:
		var passes := int(u["passes"])
		var acc := 100 if passes == 0 else int(round(100.0 * float(u["passes_ok"]) / float(passes)))
		t += "\nRating %.1f · %d min\n" % [float(u["rating"]), int(u["minutes"])]
		t += "Goals %d · Assists %d · Shots %d · Tackles %d\n" % [int(u["goals"]), int(u["assists"]), int(u["shots"]), int(u["tackles"])]
		t += "Pass accuracy %d%% (%d/%d) · Distance %.1f km\n" % [acc, int(u["passes_ok"]), passes, float(u["distance"]) / 1000.0]
	else:
		t += "\n" + str(res.get("status", "")) + "\n"
	t += "\nManager: " + str(r["feedback"])
	if str(r["media"]) != "":
		t += "\nMedia: " + str(r["media"])
	UI.modal(self, "Full time", t, [["Continue", _show_summary]])
	_build()


func _show_summary() -> void:
	var s := str(Game.career.get("pending_summary", ""))
	if s == "":
		return
	Game.career["pending_summary"] = ""
	Game.save_career()
	UI.modal(self, "End of season", s, [["Continue", _build]])


func _train() -> void:
	var opts := [
		["Attacking", _do_train.bind("attack")],
		["Defending", _do_train.bind("defend")],
		["Passing", _do_train.bind("passing")],
		["Fitness", _do_train.bind("fitness")],
		["Rest", _do_train.bind("rest")],
		["Cancel", Callable()],
	]
	UI.modal(self, "Training", "Choose this week's session. Training adds fatigue; rest recovers it.", opts)


func _do_train(kind: String) -> void:
	var msg := Game.train(kind)
	_build()
	UI.modal(self, "Training", msg, [["OK", Callable()]])


func _table() -> void:
	var g := GridContainer.new()
	g.columns = 8
	g.add_theme_constant_override("h_separation", 18)
	for h in ["#", "Club", "P", "W", "D", "L", "GD", "Pts"]:
		g.add_child(UI.label(h, 20, UI.MUTED))
	var i := 1
	for e in Game.table_sorted():
		var r: Dictionary = e["r"]
		var mine: bool = e["id"] == Game.career["club_id"]
		var col: Color = UI.ACCENT if mine else Color.WHITE
		var gd := int(r["gf"]) - int(r["ga"])
		var vals := [str(i), Game.club_name(str(e["id"])), str(int(r["p"])), str(int(r["w"])), str(int(r["d"])), str(int(r["l"])), "%+d" % gd, str(int(r["pts"]))]
		for vt in vals:
			g.add_child(UI.label(vt, 20, col))
		i += 1
	UI.modal(self, "%s %s" % [Game.world["league"], Game.season_label()], g, [["Close", Callable()]], 340)


func _stats() -> void:
	var c: Dictionary = Game.career
	var cur: Dictionary = c["cur"]
	var tot: Dictionary = c["totals"]
	var t := "This season: %s\n" % _stat_line(cur)
	t += "Career: %s\n" % _stat_line(tot)
	t += "Clubs: %s\n" % ", ".join(c["clubs_history"])
	t += "Trophies: %s\n" % ("none yet" if (c["trophies"] as Array).is_empty() else ", ".join(c["trophies"]))
	t += "Awards: %s\n" % ("none yet" if (c["awards"] as Array).is_empty() else ", ".join(c["awards"]))
	t += "\nAttributes:\n"
	var a: Dictionary = c["attrs"]
	for k in Game.ATTRS:
		if k == "goalkeeping" and str(c["pos"]) != "GK":
			continue
		t += "  %s: %d\n" % [str(k).replace("_", " ").capitalize(), int(a[k])]
	if not (c["seasons"] as Array).is_empty():
		t += "\nSeason history:\n"
		for s in c["seasons"]:
			t += "  %s · %s · %s · %d apps, %d goals, %d assists · avg %.2f · OVR %d\n" % [s["label"], s["club"], Game.ordinal(int(s["pos"])), int(s["apps"]), int(s["goals"]), int(s["assists"]), float(s["rating"]), int(s["ovr"])]
	UI.modal(self, "Career statistics", t, [["Close", Callable()]], 340)


func _stat_line(s: Dictionary) -> String:
	var apps := int(s["apps"])
	var avg := 0.0 if apps == 0 else float(s["rating_sum"]) / apps
	return "%d apps · %d goals · %d assists · %d YC · %d RC · avg %.2f" % [apps, int(s["goals"]), int(s["assists"]), int(s["yellow"]), int(s["red"]), avg]


func _transfers() -> void:
	get_tree().change_scene_to_file("res://scenes/transfers.tscn")


func _save() -> void:
	Game.save_career()
	UI.modal(self, "Saved", "Career saved to slot %d." % Game.slot, [["OK", Callable()]])


func _menu() -> void:
	Game.save_career()
	get_tree().change_scene_to_file("res://scenes/main_menu.tscn")
